<?php

declare(strict_types=1);

namespace AltContext\Sovereign\Sync;

use AltContext\Sovereign\Repositories\ClustersRepositoryInterface;
use AltContext\Sovereign\Repositories\IdentityMembersRepositoryInterface;
use AltContext\Sovereign\Repositories\SyncStateRepositoryInterface;
use RuntimeException;
use Throwable;

use function do_action;
use function function_exists;
use function is_int;
use function is_array;
use function is_object;
use function method_exists;
use function json_decode;
use function trim;
use function array_values;
use function array_fill_keys;
use function array_key_exists;
use function count;
use function max;

class SnapshotProjector implements SnapshotProjectorInterface {
	private ClustersRepositoryInterface $clusters_repository;
	private IdentityMembersRepositoryInterface $members_repository;
	private SyncStateRepositoryInterface $sync_state_repository;
	private ConflictRepository $conflict_repository;

	public function __construct(
		ClustersRepositoryInterface $clusters_repository,
		IdentityMembersRepositoryInterface $members_repository,
		SyncStateRepositoryInterface $sync_state_repository,
		?ConflictRepository $conflict_repository = null
	) {
		$this->clusters_repository   = $clusters_repository;
		$this->members_repository    = $members_repository;
		$this->sync_state_repository = $sync_state_repository;
		$this->conflict_repository   = $conflict_repository ?? new ConflictRepository();
	}

	/**
	 * @param array<string,mixed> $snapshot
	 * @throws RuntimeException When transaction support is unavailable.
	 * @throws Throwable Re-throws repository errors after rollback.
	 */
	public function project( string $tenant_id, array $snapshot ): void {
		global $wpdb;

		$normalized_tenant_id = trim( $tenant_id );
		if ( '' === $normalized_tenant_id ) {
			$this->log_empty_tenant_id_guard();
			return;
		}

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'query' ) ) {
			throw new RuntimeException( 'Snapshot projection requires $wpdb query support.' );
		}

		$started = false !== $wpdb->query( 'START TRANSACTION' );
		if ( ! $started ) {
			throw new RuntimeException( 'Snapshot projection requires transaction support.' );
		}

		try {
			$snapshot_version = (int) ( $snapshot['snapshot_version'] ?? 0 );
			$clusters         = is_array( $snapshot['clusters'] ?? null ) ? $snapshot['clusters'] : array();
			$members          = is_array( $snapshot['members'] ?? null ) ? $snapshot['members'] : array();
			$is_empty_snapshot = ( true === ( $snapshot['empty'] ?? false ) )
				|| ( empty( $clusters ) && 0 === $snapshot_version );

			if ( $is_empty_snapshot ) {
				$this->sync_state_repository->upsert_snapshot_version( $normalized_tenant_id, 0 );
				$this->sync_state_repository->refresh_curation_metrics( $normalized_tenant_id );
				$committed = false !== $wpdb->query( 'COMMIT' );
				if ( ! $committed ) {
					throw new RuntimeException( 'Snapshot projection failed to commit transaction.' );
				}
				return;
			}

			$pre_projection_conflict_count = $this->sync_state_repository->get_conflict_count( $normalized_tenant_id );

			$this->record_person_name_conflicts( $normalized_tenant_id, $clusters, $snapshot_version );
			$this->record_curated_cluster_deletion_conflicts( $normalized_tenant_id, $clusters, $snapshot_version );

			$this->clusters_repository->merge_snapshot_for_tenant( $normalized_tenant_id, $clusters, $snapshot_version );
			$this->members_repository->merge_snapshot_for_tenant( $normalized_tenant_id, $members, $snapshot_version );
			$this->sync_state_repository->upsert_snapshot_version( $normalized_tenant_id, $snapshot_version );
			$this->sync_state_repository->refresh_curation_metrics( $normalized_tenant_id );
			$post_projection_conflict_count = $this->sync_state_repository->get_conflict_count( $normalized_tenant_id );
			$conflicts_generated            = max( 0, $post_projection_conflict_count - $pre_projection_conflict_count );

			if ( function_exists( 'do_action' ) ) {
				$non_singleton_count = count(
					array_filter(
						$clusters,
						static function ( $cluster ): bool {
							return is_array( $cluster ) && (int) ( $cluster['identity_count'] ?? 0 ) > 1;
						}
					)
				);
				do_action( 'acx_snapshot_projected', $normalized_tenant_id, count( $clusters ), $non_singleton_count, $snapshot_version );
			}

			if ( $conflicts_generated > 0 && function_exists( 'do_action' ) ) {
				do_action( 'acx_projection_conflicts_detected', $conflicts_generated, $normalized_tenant_id );
			}

			$committed = false !== $wpdb->query( 'COMMIT' );
			if ( ! $committed ) {
				throw new RuntimeException( 'Snapshot projection failed to commit transaction.' );
			}
		} catch ( Throwable $throwable ) {
			$wpdb->query( 'ROLLBACK' );
			throw $throwable;
		}
	}

	/**
	 * @param array<string,mixed> $delta
	 * @throws RuntimeException When transaction support is unavailable or commit fails.
	 * @throws Throwable When downstream projection or repository writes fail after the transaction starts.
	 */
	public function project_delta( string $tenant_id, array $delta ): void {
		global $wpdb;

		$normalized_tenant_id = trim( $tenant_id );
		if ( '' === $normalized_tenant_id ) {
			$this->log_empty_tenant_id_guard();
			return;
		}

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'query' ) ) {
			throw new RuntimeException( 'Snapshot projection requires $wpdb query support.' );
		}

		$started = false !== $wpdb->query( 'START TRANSACTION' );
		if ( ! $started ) {
			throw new RuntimeException( 'Snapshot projection requires transaction support.' );
		}

		try {
			$snapshot_version = (int) ( $delta['snapshot_version'] ?? 0 );
			$clusters         = is_array( $delta['clusters'] ?? null ) ? $delta['clusters'] : array();
			$members          = is_array( $delta['members'] ?? null ) ? $delta['members'] : array();

			if ( ! empty( $clusters ) || ! empty( $members ) ) {
				$snapshot_clusters = $this->build_delta_cluster_snapshot_payload( $normalized_tenant_id, $clusters );
				$snapshot_members  = $this->build_delta_member_snapshot_payload( $normalized_tenant_id, $snapshot_clusters, $clusters, $members );
				$pre_projection_conflict_count = $this->sync_state_repository->get_conflict_count( $normalized_tenant_id );

				$this->clusters_repository->merge_snapshot_for_tenant( $normalized_tenant_id, $snapshot_clusters, $snapshot_version );
				$this->members_repository->merge_snapshot_for_tenant( $normalized_tenant_id, $snapshot_members, $snapshot_version );
				$this->sync_state_repository->upsert_snapshot_version( $normalized_tenant_id, $snapshot_version );
				$this->sync_state_repository->refresh_curation_metrics( $normalized_tenant_id );
				$post_projection_conflict_count = $this->sync_state_repository->get_conflict_count( $normalized_tenant_id );
				$conflicts_generated            = max( 0, $post_projection_conflict_count - $pre_projection_conflict_count );

				if ( $conflicts_generated > 0 && function_exists( 'do_action' ) ) {
					do_action( 'acx_projection_conflicts_detected', $conflicts_generated, $normalized_tenant_id );
				}
			} else {
				$this->sync_state_repository->upsert_snapshot_version( $normalized_tenant_id, $snapshot_version );
				$this->sync_state_repository->refresh_curation_metrics( $normalized_tenant_id );
			}

			$committed = false !== $wpdb->query( 'COMMIT' );
			if ( ! $committed ) {
				throw new RuntimeException( 'Snapshot projection failed to commit transaction.' );
			}
		} catch ( Throwable $throwable ) {
			$wpdb->query( 'ROLLBACK' );
			throw $throwable;
		}
	}

	/**
	 * @param array<int,array<string,mixed>> $changed_clusters
	 * @return array<int,array<string,mixed>>
	 */
	private function build_delta_cluster_snapshot_payload( string $tenant_id, array $changed_clusters ): array {
		$existing_clusters = $this->list_all_clusters_for_tenant( $tenant_id );
		$changed_by_id     = array();

		foreach ( $changed_clusters as $cluster ) {
			if ( ! is_array( $cluster ) ) {
				continue;
			}

			$cluster_uuid = trim( (string) ( $cluster['cluster_uuid'] ?? '' ) );
			if ( '' === $cluster_uuid ) {
				continue;
			}

			$changed_by_id[ $cluster_uuid ] = $cluster;
		}

		$payload = array();
		foreach ( $existing_clusters as $cluster ) {
			if ( ! is_array( $cluster ) ) {
				continue;
			}

			$cluster_uuid = trim( (string) ( $cluster['cluster_uuid'] ?? '' ) );
			if ( '' === $cluster_uuid ) {
				continue;
			}

			if ( isset( $changed_by_id[ $cluster_uuid ] ) ) {
				$payload[] = $changed_by_id[ $cluster_uuid ];
				unset( $changed_by_id[ $cluster_uuid ] );
				continue;
			}

			$payload[] = $cluster;
		}

		foreach ( $changed_by_id as $cluster ) {
			$payload[] = $cluster;
		}

		return $payload;
	}

	/**
	 * @param array<int,array<string,mixed>> $snapshot_clusters
	 * @param array<int,array<string,mixed>> $changed_clusters
	 * @param array<int,array<string,mixed>> $changed_members
	 * @return array<int,array<string,mixed>>
	 */
	private function build_delta_member_snapshot_payload( string $tenant_id, array $snapshot_clusters, array $changed_clusters, array $changed_members ): array {
		$cluster_ids = array();
		foreach ( $snapshot_clusters as $cluster ) {
			if ( ! is_array( $cluster ) ) {
				continue;
			}

			$cluster_uuid = trim( (string) ( $cluster['cluster_uuid'] ?? '' ) );
			if ( '' !== $cluster_uuid ) {
				$cluster_ids[] = $cluster_uuid;
			}
		}

		$existing_members_by_cluster = $this->list_all_members_by_cluster( $tenant_id, $cluster_ids );
		$changed_cluster_ids         = array_fill_keys( $this->extract_cluster_ids( $changed_clusters ), true );
		$changed_members_by_cluster  = array();

		foreach ( $changed_members as $member ) {
			if ( ! is_array( $member ) ) {
				continue;
			}

			$cluster_uuid = trim( (string) ( $member['cluster_uuid'] ?? '' ) );
			if ( '' === $cluster_uuid ) {
				continue;
			}

			if ( ! isset( $changed_members_by_cluster[ $cluster_uuid ] ) ) {
				$changed_members_by_cluster[ $cluster_uuid ] = array();
			}

			$changed_members_by_cluster[ $cluster_uuid ][] = $member;
		}

		$payload = array();
		foreach ( $cluster_ids as $cluster_uuid ) {
			if ( isset( $changed_cluster_ids[ $cluster_uuid ] ) ) {
				foreach ( $changed_members_by_cluster[ $cluster_uuid ] ?? array() as $member ) {
					$payload[] = $member;
				}
				continue;
			}

			foreach ( $existing_members_by_cluster[ $cluster_uuid ] ?? array() as $member ) {
				if ( is_array( $member ) ) {
					$payload[] = $this->hydrate_existing_member_snapshot_row( $member );
				}
			}
		}

		return $payload;
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	private function list_all_clusters_for_tenant( string $tenant_id ): array {
		$offset   = 0;
		$page_size = 5000;
		$clusters = array();

		do {
			$page = $this->clusters_repository->list_for_tenant( $tenant_id, $page_size, $offset );
			foreach ( $page as $cluster ) {
				if ( is_array( $cluster ) ) {
					$clusters[] = $cluster;
				}
			}

			$page_count = count( $page );
			$offset    += $page_count;
		} while ( $page_count === $page_size );

		return $clusters;
	}

	/**
	 * @param string[] $cluster_ids
	 * @return array<string,array<int,array<string,mixed>>>
	 */
	private function list_all_members_by_cluster( string $tenant_id, array $cluster_ids ): array {
		$members_by_cluster = array();

		foreach ( $cluster_ids as $cluster_id ) {
			$offset    = 0;
			$page_size = 500;
			$members   = array();

			do {
				$page = $this->members_repository->list_for_cluster( $cluster_id, $page_size, $offset, $tenant_id );
				foreach ( $page as $member ) {
					if ( is_array( $member ) ) {
						$members[] = $member;
					}
				}

				$page_count = count( $page );
				$offset    += $page_count;
			} while ( $page_count === $page_size );

			$members_by_cluster[ $cluster_id ] = $members;
		}

		return $members_by_cluster;
	}

	/**
	 * @param array<int,array<string,mixed>> $clusters
	 * @return string[]
	 */
	private function extract_cluster_ids( array $clusters ): array {
		$cluster_ids = array();
		foreach ( $clusters as $cluster ) {
			if ( ! is_array( $cluster ) ) {
				continue;
			}

			$cluster_uuid = trim( (string) ( $cluster['cluster_uuid'] ?? '' ) );
			if ( '' !== $cluster_uuid ) {
				$cluster_ids[] = $cluster_uuid;
			}
		}

		return array_values( array_unique( $cluster_ids ) );
	}

	/**
	 * @param array<string,mixed> $member
	 * @return array<string,mixed>
	 */
	private function hydrate_existing_member_snapshot_row( array $member ): array {
		$row = array(
			'identity_uuid' => trim( (string) ( $member['identity_uuid'] ?? '' ) ),
			'cluster_uuid'  => trim( (string) ( $member['cluster_uuid'] ?? '' ) ),
			'attachment_id' => (int) ( $member['attachment_id'] ?? 0 ),
			'thumb_path'    => trim( (string) ( $member['thumb_path'] ?? '' ) ),
			'similarity'    => $member['similarity'] ?? null,
		);

		$bbox_json = $member['bbox_json'] ?? null;
		if ( is_string( $bbox_json ) && '' !== trim( $bbox_json ) ) {
			$decoded_bbox = json_decode( $bbox_json, true );
			if ( is_array( $decoded_bbox ) ) {
				$row['bbox'] = $decoded_bbox;
			}
		}

		if ( array_key_exists( 'image_width', $member ) && is_int( $member['image_width'] ) ) {
			$row['image_width'] = $member['image_width'];
		}
		if ( array_key_exists( 'image_height', $member ) && is_int( $member['image_height'] ) ) {
			$row['image_height'] = $member['image_height'];
		}

		return $row;
	}

	/**
	 * @param array<int,array<string,mixed>> $incoming_clusters
	 */
	private function record_curated_cluster_deletion_conflicts( string $tenant_id, array $incoming_clusters, int $snapshot_version ): void {
		$curated_clusters = $this->clusters_repository->get_curated_clusters_for_tenant( $tenant_id );
		if ( empty( $curated_clusters ) ) {
			return;
		}

		$incoming_cluster_ids = array();
		foreach ( $incoming_clusters as $cluster ) {
			if ( ! is_array( $cluster ) ) {
				continue;
			}

			$cluster_uuid = trim( (string) ( $cluster['cluster_uuid'] ?? '' ) );
			if ( '' !== $cluster_uuid ) {
				$incoming_cluster_ids[ $cluster_uuid ] = true;
			}
		}

		foreach ( $curated_clusters as $cluster_uuid => $cluster ) {
			if ( isset( $incoming_cluster_ids[ $cluster_uuid ] ) || ! is_array( $cluster ) ) {
				continue;
			}

			$this->conflict_repository->record_projection_conflict(
				$tenant_id,
				'cluster',
				(string) $cluster_uuid,
				'curated_cluster_deleted',
				$snapshot_version,
				max( 0, (int) ( $cluster['snapshot_version'] ?? 0 ) ),
				max( 0, (int) ( $cluster['local_revision'] ?? 0 ) ),
				array(
					'cluster_uuid' => (string) $cluster_uuid,
					'status' => 'missing_from_snapshot',
				),
				array(
					'cluster_uuid' => (string) $cluster_uuid,
					'label' => $cluster['label'] ?? null,
					'person_id' => $cluster['person_id'] ?? null,
					'curation_state' => $cluster['curation_state'] ?? null,
				)
			);
		}
	}

	/**
	 * @param array<int,array<string,mixed>> $incoming_clusters
	 */
	private function record_person_name_conflicts( string $tenant_id, array $incoming_clusters, int $snapshot_version ): void {
		$curated_clusters = $this->clusters_repository->get_curated_clusters_for_tenant( $tenant_id );
		if ( empty( $curated_clusters ) ) {
			return;
		}

		$incoming_clusters_by_id = array();
		foreach ( $incoming_clusters as $cluster ) {
			if ( ! is_array( $cluster ) ) {
				continue;
			}

			$cluster_uuid = trim( (string) ( $cluster['cluster_uuid'] ?? '' ) );
			if ( '' === $cluster_uuid ) {
				continue;
			}

			$incoming_clusters_by_id[ $cluster_uuid ] = $cluster;
		}

		foreach ( $curated_clusters as $cluster_uuid => $cluster ) {
			if ( ! is_array( $cluster ) ) {
				continue;
			}

			$incoming_cluster = $incoming_clusters_by_id[ $cluster_uuid ] ?? null;
			if ( ! is_array( $incoming_cluster ) ) {
				continue;
			}

			$incoming_label = trim( (string) ( $incoming_cluster['label'] ?? $incoming_cluster['cluster_label'] ?? '' ) );
			$current_label = trim( (string) ( $cluster['label'] ?? $cluster['cluster_label'] ?? '' ) );
			$person_id = trim( (string) ( $cluster['person_id'] ?? '' ) );

			if ( '' === $person_id || '' === $incoming_label || '' === $current_label || $incoming_label === $current_label ) {
				continue;
			}

			$this->conflict_repository->record_projection_conflict(
				$tenant_id,
				'cluster',
				(string) $cluster_uuid,
				'person_name_conflict',
				$snapshot_version,
				max( 0, (int) ( $cluster['snapshot_version'] ?? 0 ) ),
				max( 0, (int) ( $cluster['local_revision'] ?? 0 ) ),
				array(
					'cluster_uuid' => (string) $cluster_uuid,
					'proposed_value' => $incoming_label,
					'status' => 'name_changed_from_snapshot',
				),
				array(
					'cluster_uuid' => (string) $cluster_uuid,
					'label' => $current_label,
					'person_id' => $cluster['person_id'] ?? null,
					'curation_state' => $cluster['curation_state'] ?? null,
				)
			);
		}
	}

	private function log_empty_tenant_id_guard(): void {
		if ( function_exists( 'do_action' ) ) {
			do_action(
				'acx_sovereign_warning',
				'empty_tenant_id',
				array(
					'method' => __METHOD__,
				)
			);
		}

		if ( function_exists( '_doing_it_wrong' ) ) {
			_doing_it_wrong( __METHOD__, 'Tenant ID must be non-empty for snapshot projection.', '4.13.1' );
		}
	}
}
