<?php
declare(strict_types=1);

namespace AltContext\Admin;

class Menu {

	private DashboardPage $dashboardPage;
	private WorkbenchPage $workbenchPage;
	private RosterPage $rosterPage;
	private SettingsPage $settingsPage;

	public function __construct(
		DashboardPage $dashboardPage,
		WorkbenchPage $workbenchPage,
		RosterPage $rosterPage,
		SettingsPage $settingsPage
	) {
		$this->dashboardPage  = $dashboardPage;
		$this->workbenchPage  = $workbenchPage;
		$this->rosterPage = $rosterPage;
		$this->settingsPage = $settingsPage;
	}

	public function init(): void {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
	}

	public function register_menu(): void {
		add_menu_page(
			__( 'Alt Context', 'alt-context' ),
			__( 'Alt Context', 'alt-context' ),
			'manage_options',
			'alt-context-dashboard',
			array( $this, 'render_dashboard_page' ),
			'dashicons-universal-access-alt',
			60
		);

		add_submenu_page(
			'alt-context-dashboard',
			__( 'Dashboard Overview', 'alt-context' ),
			__( 'Dashboard Overview', 'alt-context' ),
			'manage_options',
			'alt-context-dashboard',
			array( $this, 'render_dashboard_page' )
		);

		add_submenu_page(
			'alt-context-dashboard',
			__( 'Alt Context Workbench', 'alt-context' ),
			__( 'Workbench', 'alt-context' ),
			'manage_options',
			'alt-context-workbench',
			array( $this, 'render_workbench_page' )
		);

		add_submenu_page(
			'alt-context-dashboard',
			__( 'Alt Context Roster', 'alt-context' ),
			__( 'Roster', 'alt-context' ),
			'manage_options',
			'alt-context-roster',
			array( $this, 'render_roster_page' )
		);

		add_submenu_page(
			'alt-context-dashboard',
			__( 'Alt Context Settings', 'alt-context' ),
			__( 'Settings', 'alt-context' ),
			'manage_options',
			'alt-context-settings',
			array( $this, 'render_settings_page' )
		);
	}

	public function render_dashboard_page(): void {
		$this->dashboardPage->render();
	}

	public function render_workbench_page(): void {
		$this->workbenchPage->render();
	}

	public function render_roster_page(): void {
		$this->rosterPage->render();
	}

	public function render_settings_page(): void {
		$this->settingsPage->render();
	}
}
