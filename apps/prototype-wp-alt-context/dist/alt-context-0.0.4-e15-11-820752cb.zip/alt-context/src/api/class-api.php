<?php

declare(strict_types=1);

namespace AltContext\Api;

require_once __DIR__ . '/class-media-detail-controller.php';
require_once __DIR__ . '/../sovereign/sync/class-outbox-drain.php';
require_once __DIR__ . '/../sovereign/sync/class-outbox-writer.php';
require_once __DIR__ . '/../sovereign/sync/class-split-topology-command-drain.php';

use AltContext\Api\RecognitionController;
use AltContext\Sovereign\Sync\OutboxDrain;
use AltContext\Sovereign\Sync\OutboxWriter;
use AltContext\Sovereign\Sync\SplitTopologyCommandDrain;
use WP_Error;
use WP_Query;
use WP_REST_Request;
use WP_REST_Response;
use function absint;
use function add_action;
use function current_time;
use function current_user_can;
use function get_edit_post_link;
use function get_option;
use function get_post_meta;
use function get_post_mime_type;
use function get_post_modified_time;
use function get_site_url;
use function get_the_title;
use function is_array;
use function is_object;
use function is_wp_error;
use function md5;
use function method_exists;
use function register_rest_route;
use function rest_ensure_response;
use function sanitize_text_field;
use function sprintf;
use function update_option;
use function wp_get_attachment_image_sizes;
use function wp_get_attachment_image_src;
use function wp_get_attachment_image_srcset;
use function wp_get_attachment_image_url;
use function wp_get_attachment_metadata;
use function wp_get_object_terms;
use function wp_generate_uuid4;

class Api {
	private RecognitionController $recognitionController;
	private MediaDetailController $mediaDetailController;
	private SettingsController $settingsController;
	private ?XmpEmbedController $xmpEmbedController;
	private OutboxDrain $outboxDrain;
	private SplitTopologyCommandDrain $splitTopologyCommandDrain;

	public function __construct( ?XmpEmbedController $xmp_embed_controller = null, ?OutboxDrain $outbox_drain = null, ?SplitTopologyCommandDrain $split_topology_command_drain = null ) {
		$this->recognitionController = new RecognitionController();
		$this->mediaDetailController = new MediaDetailController();
		$this->settingsController = new SettingsController();
		$this->xmpEmbedController = $xmp_embed_controller;
		$this->outboxDrain = $outbox_drain ?? new OutboxDrain();
		$this->splitTopologyCommandDrain = $split_topology_command_drain ?? new SplitTopologyCommandDrain();
	}

	public function init(): void {
		$this->outboxDrain->register();
		$this->splitTopologyCommandDrain->register();
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes(): void {
		register_rest_route(
			'acx/v1',
			'/workbench/media',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_workbench_media' ),
				'permission_callback' => array( $this, 'can_view_media_queue' ),
				'args'                => $this->get_workbench_media_args(),
			)
		);

		register_rest_route(
			'acx/v1',
			'/workbench/media/detail',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this->mediaDetailController, 'get_media_details' ),
				'permission_callback' => array( $this, 'can_view_media_queue' ),
				'args'                => $this->get_workbench_media_detail_args(),
			)
		);

		register_rest_route(
			'acx/v1',
			'/dashboard/stats',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_dashboard_stats' ),
				'permission_callback' => array( $this, 'can_manage_roster' ),
			)
		);

		register_rest_route(
			'acx/v1',
			'/roster/persons',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'create_person' ),
				'permission_callback' => array( $this, 'can_manage_roster' ),
				'args'                => array(
					'name' => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'tags' => array(
						'type'    => 'array',
						'default' => array(),
						'items'   => array( 'type' => 'string' ),
					),
				),
			)
		);

		register_rest_route(
			'acx/v1',
			'/roster/persons/(?P<id>\d+)',
			array(
				array(
					'methods'             => 'PUT',
					'callback'            => array( $this, 'update_person' ),
					'permission_callback' => array( $this, 'can_manage_roster' ),
					'args'                => array(
						'name' => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'tags' => array(
							'type'  => 'array',
							'items' => array( 'type' => 'string' ),
						),
					),
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => array( $this, 'delete_person' ),
					'permission_callback' => array( $this, 'can_manage_roster' ),
				),
			)
		);

		register_rest_route(
			'acx/v1',
			'/roster/entries',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_roster_entries' ),
				'permission_callback' => array( $this, 'can_manage_roster' ),
			)
		);

		register_rest_route(
			'acx/v1',
			'/roster/clusters/(?P<cluster_id>[a-f0-9-]+)/commit',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'commit_roster_cluster' ),
				'permission_callback' => array( $this, 'can_manage_roster' ),
			)
		);

		$this->recognitionController->register_routes();
		$this->settingsController->register_routes();
		if ( $this->xmpEmbedController instanceof XmpEmbedController ) {
			$this->xmpEmbedController->register_routes();
		}
	}

	public function can_view_media_queue(): bool {
		return current_user_can( 'upload_files' );
	}

	public function can_manage_roster(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Handle GET /workbench/media requests.
	 *
	 * Note: per_page limits are enforced via REST API schema validation (see get_workbench_media_args).
	 */
	public function get_workbench_media( WP_REST_Request $request ): WP_REST_Response {
		$page     = (int) $request->get_param( 'page' );
		$per_page = (int) $request->get_param( 'per_page' );
		$search   = (string) $request->get_param( 'search' );
		$status   = (string) $request->get_param( 'status' );

		$args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => 'image',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'fields'         => 'ids',
		);

		if ( ! empty( $search ) ) {
			$args['s'] = $search;
		}

		if ( 'missing' === $status ) {
			$args['meta_query'] = array(
				'relation' => 'OR',
				array(
					'key'     => '_wp_attachment_image_alt',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => '_wp_attachment_image_alt',
					'value'   => '',
					'compare' => '=',
				),
			);
		}

		$query       = new WP_Query( $args );
		$attachments = $query->posts;

		$items = array_map(
			function ( int $attachment_id ): array {
				$alt_text = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
				$thumb_medium = wp_get_attachment_image_src( $attachment_id, 'medium' );
				$thumb_url    = wp_get_attachment_image_url( $attachment_id, 'full' );
				$thumb        = is_array( $thumb_medium ) && isset( $thumb_medium[0] ) ? $thumb_medium[0] : $thumb_url;
				$thumb_width  = is_array( $thumb_medium ) && isset( $thumb_medium[1] ) ? (int) $thumb_medium[1] : null;
				$thumb_height = is_array( $thumb_medium ) && isset( $thumb_medium[2] ) ? (int) $thumb_medium[2] : null;
				$thumb_srcset = wp_get_attachment_image_srcset( $attachment_id, 'medium' );
				$thumb_sizes  = wp_get_attachment_image_sizes( $attachment_id, 'medium' );
				$terms    = wp_get_object_terms( $attachment_id, 'post_tag', array( 'fields' => 'names' ) );

				return array(
					'id'           => $attachment_id,
					'title'        => get_the_title( $attachment_id ),
					'status'       => '' === trim( (string) $alt_text ) ? 'missing' : 'complete',
					'thumbnailUrl' => false === $thumb ? null : $thumb,
					'thumbnailSrcset' => is_string( $thumb_srcset ) ? $thumb_srcset : null,
					'thumbnailSizes'  => is_string( $thumb_sizes ) ? $thumb_sizes : null,
					'thumbnailDimensions' => array(
						'width'  => $thumb_width,
						'height' => $thumb_height,
					),
					'altText'      => '' === trim( (string) $alt_text ) ? null : $alt_text,
					'editUrl'      => get_edit_post_link( $attachment_id, '' ),
					'tags'         => is_wp_error( $terms ) || ! is_array( $terms ) ? array() : array_values( $terms ),
				);
			},
			$attachments
		);

		$response = array(
			'items'      => $items,
			'total'      => (int) $query->found_posts,
			'totalPages' => max( 1, (int) $query->max_num_pages ),
		);

		return rest_ensure_response( $response );
	}

	/**
	 * Allowed query parameters for workbench media listing.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private function get_workbench_media_args(): array {
		return array(
			'page'     => array(
				'description'       => 'Page number (1-indexed).',
				'type'              => 'integer',
				'default'           => 1,
				'sanitize_callback' => 'absint',
				'minimum'           => 1,
			),
			'per_page' => array(
				'description'       => 'Items per page.',
				'type'              => 'integer',
				'default'           => 20,
				'sanitize_callback' => 'absint',
				'minimum'           => 1,
				'maximum'           => 100,
			),
			'search'   => array(
				'description'       => 'Optional search term applied to attachment title and meta.',
				'type'              => 'string',
				'required'          => false,
				'sanitize_callback' => 'sanitize_text_field',
			),
			'status'   => array(
				'description' => 'Filter by media status.',
				'type'        => 'string',
				'default'     => 'all',
				'enum'        => array( 'missing', 'all' ),
			),
		);
	}

	/**
	 * Allowed query parameters for deferred workbench media detail loading.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private function get_workbench_media_detail_args(): array {
		return array(
			'ids' => array(
				'description' => 'Attachment IDs to enrich after the initial shell paint.',
				'type'        => 'array',
				'required'    => false,
				'items'       => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
			),
		);
	}

	public function get_roster_entries( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		global $wpdb;

		$table_persons  = $wpdb->prefix . 'acx_persons';
		$table_clusters = $wpdb->prefix . 'acx_clusters';
		$results = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT p.*, (SELECT COUNT(*) FROM %i c WHERE c.person_id = p.id) AS cluster_count FROM %i p ORDER BY p.name ASC',
				$table_clusters,
				$table_persons
			),
			ARRAY_A
		);

		if ( ! is_array( $results ) ) {
			return rest_ensure_response( array() );
		}

		// Decode tags for each person
		$entries = array_map(
			function ( $row ) {
				if ( isset( $row['tags'] ) && is_string( $row['tags'] ) ) {
					$decoded     = json_decode( $row['tags'], true );
					$row['tags'] = is_array( $decoded ) ? $decoded : array();
				}
				$row['cluster_count'] = isset( $row['cluster_count'] ) ? (int) $row['cluster_count'] : 0;
				return $row;
			},
			$results
		);

		return rest_ensure_response( $entries );
	}

	public function commit_roster_cluster( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		global $wpdb;

		$cluster_id = sanitize_text_field( (string) $request->get_param( 'cluster_id' ) );
		if ( '' === $cluster_id ) {
			return new WP_Error( 'missing_cluster_id', 'Cluster ID is required.', array( 'status' => 400 ) );
		}

		$person_id            = $request->get_param( 'roster_entry_id' );
		$new_name             = $request->get_param( 'new_entry_name' );
		$resolved_person_name = null;
		$person_uuid          = null;
		$table_persons  = $wpdb->prefix . 'acx_persons';
		$table_clusters = $wpdb->prefix . 'acx_clusters';

		if ( ! $this->begin_database_transaction() ) {
			return new WP_Error( 'acx_db_error', __( 'Could not start local transaction.', 'alt-context' ), array( 'status' => 500 ) );
		}

		// If new name provided, create person within the same transaction as the bind.
		if ( ! $person_id && $new_name ) {
			$new_name = sanitize_text_field( (string) $new_name );
			if ( ! empty( trim( $new_name ) ) ) {
				$existing = $wpdb->get_row( $wpdb->prepare( 'SELECT id, person_uuid FROM %i WHERE name = %s', $table_persons, $new_name ) );

				if ( $existing ) {
					$person_id   = (int) $existing->id;
					$person_uuid = (string) ( $existing->person_uuid ?? '' );
					$resolved_person_name = $new_name;
				} else {
					$person_uuid       = wp_generate_uuid4();
					$person_created_at = current_time( 'mysql' );
					$inserted          = $wpdb->insert(
						$table_persons,
						array(
							'person_uuid'    => $person_uuid,
							'name'           => $new_name,
							'tags'           => wp_json_encode( array() ),
							'local_revision' => 1,
							'created_at'     => $person_created_at,
							'updated_at'     => $person_created_at,
						),
						array( '%s', '%s', '%s', '%d', '%s', '%s' )
					);
					if ( false === $inserted ) {
						$this->rollback_database_transaction();
						return new WP_Error( 'acx_db_error', __( 'Could not create person for cluster assignment.', 'alt-context' ), array( 'status' => 500 ) );
					}

					$person_id = (int) $wpdb->insert_id;
					$queued_person = $this->enqueue_curation_operation(
						'person_created',
						'person',
						(string) $person_uuid,
						1,
						array(
							'person_uuid' => $person_uuid,
							'name'        => $new_name,
							'tags'        => array(),
						)
					);
					if ( ! $queued_person ) {
						$this->rollback_database_transaction();
						return new WP_Error( 'acx_db_error', __( 'Could not queue person creation replay operation.', 'alt-context' ), array( 'status' => 500 ) );
					}

					$resolved_person_name = $new_name;
				}
			}
		}

		$person_id = $person_id ? absint( $person_id ) : null;
		if ( null !== $person_id && ( ! is_string( $person_uuid ) || '' === trim( $person_uuid ) ) ) {
			$person_uuid = $this->get_person_uuid_by_id( $person_id, $table_persons );
		}

		if ( null !== $person_id && ( ! is_string( $person_uuid ) || '' === trim( $person_uuid ) ) ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not resolve person UUID for cluster assignment.', 'alt-context' ), array( 'status' => 500 ) );
		}

		if ( null !== $person_id && ( ! is_string( $resolved_person_name ) || '' === trim( $resolved_person_name ) ) ) {
			$resolved_person_name = $this->get_person_name_by_id( $person_id, $table_persons );
		}

		$now = current_time( 'mysql' );

		$update_data = array(
			'person_id'         => $person_id,
			'curation_state'    => 'confirmed',
			'is_user_confirmed' => 1,
			'updated_at'        => $now,
		);
		$update_fmt  = array( '%d', '%s', '%d', '%s' );

		if ( null === $person_id ) {
			$update_fmt[0] = null;
		} elseif ( is_string( $resolved_person_name ) && '' !== trim( $resolved_person_name ) ) {
			$update_data['label'] = trim( $resolved_person_name );
			$update_fmt[]         = '%s';
		}

		$cluster_updated = $wpdb->update(
			$table_clusters,
			$update_data,
			array( 'cluster_uuid' => $cluster_id ),
			$update_fmt,
			array( '%s' )
		);
		if ( false === $cluster_updated ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not update cluster assignment.', 'alt-context' ), array( 'status' => 500 ) );
		}

		$revision_updated = $wpdb->query(
			$wpdb->prepare(
				'UPDATE %i SET local_revision = local_revision + 1 WHERE cluster_uuid = %s',
				$table_clusters,
				$cluster_id
			)
		);
		if ( false === $revision_updated ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not update cluster revision.', 'alt-context' ), array( 'status' => 500 ) );
		}

		$local_revision = (int) $wpdb->get_var(
			$wpdb->prepare( 'SELECT local_revision FROM %i WHERE cluster_uuid = %s', $table_clusters, $cluster_id )
		);
		$queued = $this->enqueue_curation_operation(
			( null === $person_id ? 'cluster_person_unbound' : 'cluster_person_bound' ),
			'cluster',
			$cluster_id,
			max( 1, $local_revision ),
			array(
				'cluster_uuid' => $cluster_id,
				'person_uuid'  => ( null === $person_id ) ? null : ( is_string( $person_uuid ) ? $person_uuid : null ),
			)
		);
		if ( ! $queued ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not queue curation replay operation.', 'alt-context' ), array( 'status' => 500 ) );
		}

		if ( ! $this->commit_database_transaction() ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not commit local transaction.', 'alt-context' ), array( 'status' => 500 ) );
		}

		return rest_ensure_response(
			array(
				'cluster_id' => $cluster_id,
				'person_id'  => $person_id,
				'updated_at' => $now,
			)
		);
	}

	public function create_person( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		global $wpdb;

		$name = sanitize_text_field( (string) $request->get_param( 'name' ) );
		$tags = (array) $request->get_param( 'tags' );

		if ( empty( trim( $name ) ) ) {
			return new WP_Error(
				'acx_invalid_name',
				__( 'Person name cannot be empty.', 'alt-context' ),
				array( 'status' => 400 )
			);
		}

			// Check for existing name
			$table_name = $wpdb->prefix . 'acx_persons';
			$existing   = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM %i WHERE name = %s', $table_name, $name ) );
		if ( $existing ) {
			return new WP_Error( 'acx_person_exists', __( 'A person with this name already exists.', 'alt-context' ), array( 'status' => 409 ) );
		}

		$person_uuid = wp_generate_uuid4();
		$now         = current_time( 'mysql' );

		if ( ! $this->begin_database_transaction() ) {
			return new WP_Error( 'acx_db_error', __( 'Could not start local transaction.', 'alt-context' ), array( 'status' => 500 ) );
		}

		$result = $wpdb->insert(
			$table_name,
			array(
				'person_uuid' => $person_uuid,
				'name'        => $name,
				'tags'        => wp_json_encode( $tags ),
				'local_revision' => 1,
				'created_at'  => $now,
				'updated_at'  => $now,
			),
			array( '%s', '%s', '%s', '%d', '%s', '%s' )
		);

		if ( false === $result ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not create person in database.', 'alt-context' ), array( 'status' => 500 ) );
		}

		$person_id = $wpdb->insert_id;
		$queued = $this->enqueue_curation_operation(
			'person_created',
			'person',
			(string) $person_uuid,
			1,
			array(
				'person_uuid' => $person_uuid,
				'name'        => $name,
				'tags'        => $tags,
			)
		);

		if ( ! $queued ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not queue person creation replay operation.', 'alt-context' ), array( 'status' => 500 ) );
		}

		if ( ! $this->commit_database_transaction() ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not commit local transaction.', 'alt-context' ), array( 'status' => 500 ) );
		}

		return new WP_REST_Response(
			array(
				'id'          => $person_id,
				'person_uuid' => $person_uuid,
				'name'        => $name,
				'tags'        => $tags,
				'cluster_count' => 0,
				'created_at'  => $now,
				'updated_at'  => $now,
			),
			201
		);
	}

	public function update_person( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		global $wpdb;

		$id   = (int) $request->get_param( 'id' );
		$name = $request->get_param( 'name' );
		$tags = $request->get_param( 'tags' );

		if ( null !== $name && empty( trim( sanitize_text_field( (string) $name ) ) ) ) {
			return new WP_Error(
				'acx_invalid_name',
				__( 'Person name cannot be empty.', 'alt-context' ),
				array( 'status' => 400 )
			);
		}

			$table_name = $wpdb->prefix . 'acx_persons';
			$person     = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', $table_name, $id ) );

		if ( ! $person ) {
			return new WP_Error( 'acx_person_not_found', __( 'Person not found.', 'alt-context' ), array( 'status' => 404 ) );
		}

		$update_data = array();
		$update_fmt  = array();

		if ( null !== $name ) {
			$name = sanitize_text_field( (string) $name );
				// Check for conflict if name changed
			if ( $name !== $person->name ) {
				$conflict = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM %i WHERE name = %s AND id != %d', $table_name, $name, $id ) );
				if ( $conflict ) {
					return new WP_Error( 'acx_person_exists', __( 'Another person with this name already exists.', 'alt-context' ), array( 'status' => 409 ) );
				}
				$update_data['name'] = $name;
				$update_fmt[]        = '%s';
			}
		}

		if ( null !== $tags ) {
			$update_data['tags'] = wp_json_encode( (array) $tags );
			$update_fmt[]        = '%s';
		}

		if ( empty( $update_data ) ) {
			return rest_ensure_response( $person );
		}

		$now                     = current_time( 'mysql' );
		$update_data['updated_at'] = $now;
		$update_fmt[]            = '%s';

		if ( ! $this->begin_database_transaction() ) {
			return new WP_Error( 'acx_db_error', __( 'Could not start local transaction.', 'alt-context' ), array( 'status' => 500 ) );
		}

		$result = $wpdb->update( $table_name, $update_data, array( 'id' => $id ), $update_fmt, array( '%d' ) );

		if ( false === $result ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not update person in database.', 'alt-context' ), array( 'status' => 500 ) );
		}

		if ( null !== $name && $name !== $person->name && ! $this->sync_bound_cluster_labels( $id, $name, $now, $wpdb->prefix . 'acx_clusters' ) ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not sync bound cluster labels.', 'alt-context' ), array( 'status' => 500 ) );
		}

		$person_revision_updated = $wpdb->query(
			$wpdb->prepare(
				'UPDATE %i SET local_revision = local_revision + 1 WHERE id = %d',
				$table_name,
				$id
			)
		);
		if ( false === $person_revision_updated ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not update person revision.', 'alt-context' ), array( 'status' => 500 ) );
		}

		$local_revision = (int) $wpdb->get_var(
			$wpdb->prepare( 'SELECT local_revision FROM %i WHERE id = %d', $table_name, $id )
		);

			$updated_person = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', $table_name, $id ) );
		if ( isset( $updated_person->tags ) && is_string( $updated_person->tags ) ) {
			$updated_person->tags = json_decode( $updated_person->tags, true );
		}

			$queued = $this->enqueue_curation_operation(
				'person_updated',
				'person',
				(string) ( $person->person_uuid ?? $id ),
				max( 1, $local_revision ),
				array(
					'person_uuid' => (string) ( $person->person_uuid ?? '' ),
					'name'        => (string) ( $updated_person->name ?? $person->name ),
					'tags'        => $updated_person->tags ?? array(),
				)
			);

		if ( ! $queued ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not queue person update replay operation.', 'alt-context' ), array( 'status' => 500 ) );
		}

		if ( ! $this->commit_database_transaction() ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not commit local transaction.', 'alt-context' ), array( 'status' => 500 ) );
		}

		return rest_ensure_response( $updated_person );
	}

	public function delete_person( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		global $wpdb;

		$id = (int) $request->get_param( 'id' );

			$table_persons  = $wpdb->prefix . 'acx_persons';
			$table_clusters = $wpdb->prefix . 'acx_clusters';

			$person = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', $table_persons, $id ) );
		if ( ! $person ) {
			return new WP_Error( 'acx_person_not_found', __( 'Person not found.', 'alt-context' ), array( 'status' => 404 ) );
		}

		$affected_clusters = $wpdb->get_results(
			$wpdb->prepare( 'SELECT cluster_uuid FROM %i WHERE person_id = %d', $table_clusters, $id ),
			ARRAY_A
		);
		if ( ! $this->begin_database_transaction() ) {
			return new WP_Error( 'acx_db_error', __( 'Could not start local transaction.', 'alt-context' ), array( 'status' => 500 ) );
		}

		// Curated dissociation: preserve curation confirmation while clearing assignment.
		$now = current_time( 'mysql' );
		$dissociation_result = $wpdb->update(
			$table_clusters,
			array(
				'person_id'         => null,
				'curation_state'    => 'confirmed',
				'is_user_confirmed' => 1,
				'updated_at'        => $now,
			),
			array( 'person_id' => $id ),
			array( null, '%s', '%d', '%s' ),
			array( '%d' )
		);
		if ( false === $dissociation_result ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not dissociate person from clusters.', 'alt-context' ), array( 'status' => 500 ) );
		}

		if ( is_array( $affected_clusters ) ) {
			foreach ( $affected_clusters as $cluster_row ) {
				$cluster_uuid = sanitize_text_field( (string) ( $cluster_row['cluster_uuid'] ?? '' ) );
				if ( '' === $cluster_uuid ) {
					continue;
				}

				$revision_updated = $wpdb->query(
					$wpdb->prepare(
						'UPDATE %i SET local_revision = local_revision + 1 WHERE cluster_uuid = %s',
						$table_clusters,
						$cluster_uuid
					)
				);
				if ( false === $revision_updated ) {
					$this->rollback_database_transaction();
					return new WP_Error( 'acx_db_error', __( 'Could not update cluster revision.', 'alt-context' ), array( 'status' => 500 ) );
				}

				$cluster_revision = (int) $wpdb->get_var(
					$wpdb->prepare( 'SELECT local_revision FROM %i WHERE cluster_uuid = %s', $table_clusters, $cluster_uuid )
				);

				$queued = $this->enqueue_curation_operation(
					'cluster_person_unbound',
					'cluster',
					$cluster_uuid,
					max( 1, $cluster_revision ),
					array(
						'cluster_uuid' => $cluster_uuid,
						'person_uuid'  => null,
					)
				);
				if ( ! $queued ) {
					$this->rollback_database_transaction();
					return new WP_Error( 'acx_db_error', __( 'Could not queue cluster unbind replay operation.', 'alt-context' ), array( 'status' => 500 ) );
				}
			}
		}

		$result = $wpdb->delete( $table_persons, array( 'id' => $id ), array( '%d' ) );

		if ( false === $result ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not delete person from database.', 'alt-context' ), array( 'status' => 500 ) );
		}

		$person_local_revision = max( 1, (int) ( $person->local_revision ?? 0 ) + 1 );

		$queued = $this->enqueue_curation_operation(
			'person_deleted',
			'person',
			(string) ( $person->person_uuid ?? $id ),
			$person_local_revision,
			array(
				'person_uuid' => (string) ( $person->person_uuid ?? '' ),
				'person_id'   => $id,
			)
		);
		if ( ! $queued ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not queue person deletion replay operation.', 'alt-context' ), array( 'status' => 500 ) );
		}

		if ( ! $this->commit_database_transaction() ) {
			$this->rollback_database_transaction();
			return new WP_Error( 'acx_db_error', __( 'Could not commit local transaction.', 'alt-context' ), array( 'status' => 500 ) );
		}

		return rest_ensure_response( array( 'deleted' => true, 'id' => $id ) );
	}

	/**
	 * @param array<string,mixed> $payload
	 */
	private function enqueue_curation_operation(
		string $operation_type,
		string $entity_type,
		string $entity_key,
		int $local_revision,
		array $payload
	): bool {
		$tenant_id = $this->get_local_tenant_id();
		if ( '' === $tenant_id ) {
			return false;
		}

		$writer = new OutboxWriter();
		$result = $writer->enqueue(
			$tenant_id,
			$operation_type,
			$entity_type,
			$entity_key,
			$this->get_expected_base_version( $tenant_id, $entity_type, $entity_key ),
			max( 0, $local_revision ),
			$payload,
			wp_generate_uuid4()
		);

		return false !== $result;
	}

	private function begin_database_transaction(): bool {
		global $wpdb;

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'query' ) ) {
			return false;
		}

		return false !== $wpdb->query( 'START TRANSACTION' );
	}

	private function commit_database_transaction(): bool {
		global $wpdb;

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'query' ) ) {
			return false;
		}

		return false !== $wpdb->query( 'COMMIT' );
	}

	private function rollback_database_transaction(): void {
		global $wpdb;

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'query' ) ) {
			return;
		}

		$wpdb->query( 'ROLLBACK' );
	}

	private function get_person_uuid_by_id( int $person_id, string $table_persons ): ?string {
		global $wpdb;

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'get_var' ) || ! method_exists( $wpdb, 'prepare' ) ) {
			return null;
		}

		$resolved_uuid = $wpdb->get_var(
			$wpdb->prepare( 'SELECT person_uuid FROM %i WHERE id = %d', $table_persons, $person_id )
		);

		return is_string( $resolved_uuid ) && '' !== trim( $resolved_uuid ) ? $resolved_uuid : null;
	}

	private function get_person_name_by_id( int $person_id, string $table_persons ): ?string {
		global $wpdb;

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'get_var' ) || ! method_exists( $wpdb, 'prepare' ) ) {
			return null;
		}

		$resolved_name = $wpdb->get_var(
			$wpdb->prepare( 'SELECT name FROM %i WHERE id = %d', $table_persons, $person_id )
		);

		return is_string( $resolved_name ) && '' !== trim( $resolved_name ) ? trim( $resolved_name ) : null;
	}

	private function sync_bound_cluster_labels( int $person_id, string $person_name, string $updated_at, string $table_clusters ): bool {
		global $wpdb;

		if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'query' ) || ! method_exists( $wpdb, 'prepare' ) ) {
			return false;
		}

		$sql = $wpdb->prepare(
			'UPDATE %i SET label = %s, updated_at = %s, local_revision = local_revision + 1 WHERE person_id = %d',
			$table_clusters,
			trim( $person_name ),
			$updated_at,
			$person_id
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Query is prepared above and executed as-is.
		return false !== $wpdb->query( $sql );
	}

	private function get_local_tenant_id(): string {
		return md5( (string) get_site_url() );
	}

	private function get_expected_base_version( string $tenant_id, string $entity_type, string $entity_key ): int {
		global $wpdb;

		if ( ! isset( $wpdb ) ) {
			return 0;
		}

		if ( 'cluster' === $entity_type ) {
			$table_clusters = $wpdb->prefix . 'acx_clusters';
			$row_version = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT snapshot_version FROM %i WHERE cluster_uuid = %s LIMIT 1',
					$table_clusters,
					$entity_key
				)
			);
			if ( null !== $row_version ) {
				return max( 0, (int) $row_version );
			}
		}

		$table_sync = $wpdb->prefix . 'acx_sync_state';
		$stream_name = sprintf( 'tenant:%s:clusters', trim( $tenant_id ) );
		$version = $wpdb->get_var(
			$wpdb->prepare( 'SELECT last_snapshot_version FROM %i WHERE stream_name = %s LIMIT 1', $table_sync, $stream_name )
		);

		return max( 0, (int) $version );
	}

	public function get_dashboard_stats( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		global $wpdb;

			$table_persons  = $wpdb->prefix . 'acx_persons';
			$table_clusters = $wpdb->prefix . 'acx_clusters';
			$table_members  = $wpdb->prefix . 'acx_identity_members';

			$people_count = (int) $wpdb->get_var(
				$wpdb->prepare( 'SELECT COUNT(*) FROM %i', $table_persons )
			);

			$assigned_clusters = (int) $wpdb->get_var(
				$wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE person_id IS NOT NULL', $table_clusters )
			);

			$pending_clusters = (int) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM %i WHERE person_id IS NULL AND curation_state = %s',
					$table_clusters,
					'uncurated'
				)
			);

			$media_with_faces = (int) $wpdb->get_var(
				$wpdb->prepare( 'SELECT COUNT(DISTINCT media_id) FROM %i', $table_members )
			);

			$unassigned_persons = (int) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM %i p WHERE NOT EXISTS (SELECT 1 FROM %i c WHERE c.person_id = p.id)',
					$table_persons,
					$table_clusters
				)
			);

		return rest_ensure_response(
			array(
				'people_count'             => $people_count,
				'assigned_clusters_count'  => $assigned_clusters,
				'pending_clusters_count'   => $pending_clusters,
				'media_with_faces_count'   => $media_with_faces,
				'unassigned_persons_count' => $unassigned_persons,
			)
		);
	}
}
