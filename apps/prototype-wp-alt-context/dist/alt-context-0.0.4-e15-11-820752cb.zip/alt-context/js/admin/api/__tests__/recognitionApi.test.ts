import { beforeEach, describe, expect, expectTypeOf, it, vi } from 'vitest';

import * as httpModule from '../../utils/http';
import {
  fetchPendingMergeSuggestions,
  fetchPendingNameSuggestions,
  fetchPendingSuggestions,
  fetchMediaIdentities,
  fetchIdentitySuggestions,
  fetchRetentionStatus,
  fetchSyncStatus,
  fetchTopUnlabeledClusters,
  getRecognitionCluster,
  listRecognitionClusters,
  assignOutlierToCluster,
  mergeCluster,
  purgeTenantData,
  pinRepresentative,
  revertMergeCluster,
  acknowledgeProjection,
  cancelScanJob,
  downloadExportJobData,
  exportTenantData,
  scanFaces,
  triggerSync,
  undismissCluster,
  updateRetentionPolicy,
  updateClusterLabel,
  type BulkAcceptRequest,
  type BulkAcceptResponse,
  type PendingNameSuggestion,
} from '../recognition';
import { DATA_SOURCE, PROJECTION_STATUS } from '../recognition/types';

const mockConfig = {
  nonce: 'nonce-123',
  endpoints: {
    retentionPolicy: 'https://example.com/retentionPolicy',
    retentionExport: 'https://example.com/retentionExport',
    retentionPurge: 'https://example.com/retentionPurge',
  } as Record<string, string>,
  devMode: false,
};

vi.mock('../config', () => ({
  getEndpoint: vi.fn((...keys: string[]) => {
    const configuredKey = keys.find((key) => mockConfig.endpoints[key]);
    return configuredKey ? mockConfig.endpoints[configuredKey] : `https://example.com/${keys[0] ?? 'default'}`;
  }),
  getConfig: vi.fn(() => mockConfig),
  isDevMode: vi.fn(() => false),
}));

vi.mock('../../utils/http', () => {
  const requestMock = vi.fn();
  return {
    fetchApi: requestMock,
    fetchRequiredApi: requestMock,
    stripTrailingSlash: (value: string) => (value.endsWith('/') ? value.slice(0, -1) : value),
  };
});

describe('recognitionApi', () => {
  const fetchApiMock = vi.mocked(httpModule.fetchRequiredApi);
  const fetchMutationMock = vi.mocked(httpModule.fetchApi);

  beforeEach(() => {
    vi.clearAllMocks();
    mockConfig.endpoints = {
      retentionPolicy: 'https://example.com/retentionPolicy',
      retentionExport: 'https://example.com/retentionExport',
      retentionPurge: 'https://example.com/retentionPurge',
    };
  });

  it('passes media IDs to fetchMediaIdentities', async () => {
    fetchApiMock.mockResolvedValue({ identities_by_media: {}, data_source: 'backend_proxy' });
    await fetchMediaIdentities([1, 2]);
    expect(fetchApiMock).toHaveBeenCalledTimes(1);
    const [endpoint] = fetchApiMock.mock.calls[0] ?? [];
    const url = new URL(endpoint);
    expect(url.searchParams.getAll('media_ids[]')).toEqual(['1', '2']);
    expect(fetchApiMock).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        method: 'GET',
        restNonce: 'nonce-123',
      }),
    );
  });

  it('sends nonce when fetching media identities', async () => {
    fetchApiMock.mockResolvedValue({ identities_by_media: {}, data_source: 'backend_proxy' });
    await fetchMediaIdentities([99]);
    expect(fetchApiMock).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        method: 'GET',
        restNonce: 'nonce-123',
      }),
    );
  });

  it('normalizes media identity data_source metadata', async () => {
    fetchApiMock.mockResolvedValue({ identities_by_media: {}, data_source: 'backend_proxy' });

    const result = await fetchMediaIdentities([99]);

    expect(result.data_source).toBe(DATA_SOURCE.BACKEND_PROXY);
  });

  it('rejects media identity payloads without canonical metadata', async () => {
    fetchApiMock.mockResolvedValue({ identities_by_media: {} });

    await expect(fetchMediaIdentities([99])).rejects.toThrow(
      'Media identities response must include a valid data_source.',
    );
  });

  it('normalizes top-unlabeled response metadata', async () => {
    fetchApiMock.mockResolvedValue({
      clusters: [],
      singleton_count: 0,
      data_source: 'unavailable',
      projection_status: 'bootstrapping',
    });

    const result = await fetchTopUnlabeledClusters('tenant-1', 20);

    expect(result.data_source).toBe(DATA_SOURCE.UNAVAILABLE);
    expect(result.projection_status).toBe(PROJECTION_STATUS.BOOTSTRAPPING);
  });

  it('rejects top-unlabeled payloads without canonical metadata', async () => {
    fetchApiMock.mockResolvedValue({
      clusters: [],
    });

    await expect(fetchTopUnlabeledClusters('tenant-1', 20)).rejects.toThrow(
      'Top-unlabeled clusters response must include a valid data_source.',
    );
  });

  it('accepts backend-proxy top-unlabeled payloads without projection metadata', async () => {
    fetchApiMock.mockResolvedValue({
      clusters: [],
      data_source: 'backend_proxy',
    });

    const result = await fetchTopUnlabeledClusters('tenant-1', 20);

    expect(result.data_source).toBe(DATA_SOURCE.BACKEND_PROXY);
    expect(result.singleton_count).toBeUndefined();
    expect(result.projection_status).toBeUndefined();
  });

  it('normalizes pending suggestion data_source metadata', async () => {
    fetchApiMock.mockResolvedValue({
      suggestions: [],
      total: 0,
      limit: 10,
      offset: 0,
      data_source: 'backend_proxy',
    });

    const result = await fetchPendingSuggestions(10, 0);

    expect(result.data_source).toBe(DATA_SOURCE.BACKEND_PROXY);
  });

  it('rejects pending suggestion envelopes without canonical metadata', async () => {
    fetchApiMock.mockResolvedValue({
      suggestions: [],
      total: 0,
      limit: 10,
      offset: 0,
    });

    await expect(fetchPendingSuggestions(10, 0)).rejects.toThrow(
      'Pending suggestions response must include a valid data_source.',
    );
  });

  it('normalizes pending name suggestion data_source metadata', async () => {
    fetchApiMock.mockResolvedValue({
      suggestions: [],
      total: 0,
      limit: 25,
      offset: 0,
      data_source: 'unavailable',
    });

    const result = await fetchPendingNameSuggestions(0, 25, 0);

    expect(result.data_source).toBe(DATA_SOURCE.UNAVAILABLE);
  });

  it('rejects pending name suggestion envelopes without canonical metadata', async () => {
    fetchApiMock.mockResolvedValue({
      suggestions: [],
      total: 0,
      limit: 25,
      offset: 0,
    });

    await expect(fetchPendingNameSuggestions(0, 25, 0)).rejects.toThrow(
      'Pending name suggestions response must include a valid data_source.',
    );
  });

  it('calls updateClusterLabel with PATCH', async () => {
    fetchApiMock.mockResolvedValue({});
    await updateClusterLabel('cluster-1', 'New Label');
    const [, options] = fetchApiMock.mock.calls[0] ?? [];
    expect(fetchApiMock).toHaveBeenCalledWith(expect.stringContaining('/cluster-1'), expect.any(Object));
    expect(options).toMatchObject({ method: 'PATCH', body: { label: 'New Label' }, restNonce: 'nonce-123' });
  });

  it('calls mergeCluster with POST', async () => {
    fetchApiMock.mockResolvedValue({});
    await mergeCluster('source', 'target-cluster-id', 'Target Label');
    const [, options] = fetchApiMock.mock.calls[0] ?? [];
    expect(fetchApiMock).toHaveBeenCalledWith(expect.stringContaining('/source/merge'), expect.any(Object));
    expect(options).toMatchObject({
      method: 'POST',
      body: { target_cluster_id: 'target-cluster-id', target_label: 'Target Label' },
      restNonce: 'nonce-123',
    });
  });

  it('normalizes backend merge responses for the cluster edit UI', async () => {
    fetchApiMock.mockResolvedValue({
      id: 'target-cluster-id',
      label: 'Target Label',
      identity_count: 7,
    });

    const result = await mergeCluster('source-cluster-id', 'target-cluster-id', 'Target Label');

    expect(result).toEqual({
      source_id: 'source-cluster-id',
      source_label: null,
      target_id: 'target-cluster-id',
      target_label: 'Target Label',
      identities_moved: 0,
      moved_identity_ids: [],
      target_identity_count: 7,
    });
  });

  it('fetches identity suggestions with tenant nonce', async () => {
    fetchApiMock.mockResolvedValue({ matches: [] });
    await fetchIdentitySuggestions('identity-123', 3);
    const call = fetchApiMock.mock.calls[0];
    expect(call[0]).toContain('/identity-123/suggestions');
    expect(call[0]).toContain('top_k=3');
    expect(call[1]).toMatchObject({ method: 'GET', restNonce: 'nonce-123' });
  });

  it('posts revert merge payload', async () => {
    fetchApiMock.mockResolvedValue({});
    await revertMergeCluster({
      targetClusterId: 'target-1',
      movedIdentityIds: ['id-1', 'id-2'],
      sourceLabel: 'Alice',
    });
    expect(fetchApiMock).toHaveBeenCalledWith(expect.any(String), {
      method: 'POST',
      body: {
        target_cluster_id: 'target-1',
        moved_identity_ids: ['id-1', 'id-2'],
        source_label: 'Alice',
      },
      restNonce: 'nonce-123',
    });
  });

  it('posts assign outlier payload', async () => {
    fetchApiMock.mockResolvedValue({});
    await assignOutlierToCluster({
      clusterId: 'target-1',
      identityId: 'identity-1',
      similarity: 0.25,
    });
    expect(fetchApiMock).toHaveBeenCalledWith(expect.stringContaining('/target-1/assign'), {
      method: 'POST',
      body: {
        identity_id: 'identity-1',
        similarity: 0.25,
      },
      restNonce: 'nonce-123',
      signal: undefined,
    });
  });

  it('posts representative pin state to the representative pin endpoint', async () => {
    fetchApiMock.mockResolvedValue({});

    await pinRepresentative('cluster-1', 'identity-77', true);

    expect(fetchApiMock).toHaveBeenCalledWith(expect.stringContaining('/cluster-1/representatives/identity-77/pin'), {
      method: 'PATCH',
      body: { is_pinned: true },
      restNonce: 'nonce-123',
      signal: undefined,
    });
  });

  it('returns job response from backend', async () => {
    const mockResponse = {
      id: 'job-1',
      type: 'analyze',
      status: 'pending',
      progress: { completed: 0, total: 20 },
      started_at: '2025-01-01T00:00:00Z',
      finished_at: null,
    };
    fetchApiMock.mockResolvedValue(mockResponse);

    const result = await scanFaces({ mediaIds: [1, 2] });
    expect(result.id).toBe('job-1');
    expect(result.status).toBe('pending');
    expect(result.progress?.total).toBe(20);
  });

  it('starts an async export job and returns job_id and status', async () => {
    fetchApiMock.mockResolvedValue({ job_id: 'export-job-1', status: 'pending' });

    const result = await exportTenantData();

    expect(result).toEqual({ job_id: 'export-job-1', status: 'pending' });
    expect(fetchApiMock).toHaveBeenCalledWith(
      expect.stringContaining('/retentionExport'),
      expect.objectContaining({ method: 'POST', restNonce: 'nonce-123' }),
    );
  });

  it('normalizes retention export payloads from backend data/counts fields', async () => {
    fetchApiMock.mockResolvedValue({
      tenant_id: 'tenant-1',
      exported_at: '2026-03-12T12:00:00Z',
      schema_version: 1,
      counts: { clusters: 2, members: 3 },
      data: {
        clusters: [{ id: 'cluster-1' }],
      },
    });

    const result = await downloadExportJobData('export-job-1');

    expect(result).toEqual({
      tenant_id: 'tenant-1',
      exported_at: '2026-03-12T12:00:00Z',
      schema_version: 1,
      summary: { clusters: 2, members: 3 },
      payload: {
        clusters: [{ id: 'cluster-1' }],
      },
    });
    expect(fetchApiMock).toHaveBeenCalledWith(
      expect.stringContaining('/retentionExport/export-job-1/data'),
      expect.objectContaining({ method: 'GET', restNonce: 'nonce-123' }),
    );
  });

  it('exports the phase-0 suggestion stub types through the recognition barrel', () => {
    const pendingNameSuggestion = {
      id: 'name-suggestion-1',
      cluster_id: 'cluster-1',
      suggested_name: 'Taylor',
      confidence_score: 0.88,
      source: 'roster',
      created_at: '2026-03-19T12:00:00Z',
      expires_at: null,
      representatives: [],
    } satisfies PendingNameSuggestion;
    const bulkAcceptRequest = {
      suggestion_type: 'name',
      min_confidence: 0.75,
    } satisfies BulkAcceptRequest;
    const bulkAcceptResponse = {
      accepted_count: 2,
      skipped_count: 1,
    } satisfies BulkAcceptResponse;

    const representatives: PendingNameSuggestion['representatives'] = pendingNameSuggestion.representatives;

    expectTypeOf(bulkAcceptRequest.min_confidence).toMatchTypeOf<BulkAcceptRequest['min_confidence']>();
    expectTypeOf(bulkAcceptResponse.accepted_count).toMatchTypeOf<BulkAcceptResponse['accepted_count']>();

    expect(pendingNameSuggestion.id).toBe('name-suggestion-1');
    expect(representatives).toEqual([]);
    expect(bulkAcceptRequest.suggestion_type).toBe('name');
    expect(bulkAcceptResponse.accepted_count).toBe(2);
    expect(bulkAcceptResponse.skipped_count).toBe(1);
  });

  it('returns the proxied retention policy payload from updateRetentionPolicy', async () => {
    fetchApiMock.mockResolvedValue({
      retention_mode: 'purge_on_demand',
      last_export_at: '2026-03-12T12:00:00Z',
      last_purge_at: null,
      retention_updated_at: '2026-03-12T12:30:00Z',
    });

    const result = await updateRetentionPolicy({ retention_mode: 'purge_on_demand' });

    expect(result).toEqual({
      retention_mode: 'purge_on_demand',
      last_export_at: '2026-03-12T12:00:00Z',
      last_purge_at: null,
      retention_updated_at: '2026-03-12T12:30:00Z',
    });
    expect(fetchApiMock).toHaveBeenCalledWith(
      expect.stringContaining('/retentionPolicy'),
      expect.objectContaining({
        method: 'PATCH',
        body: { retention_mode: 'purge_on_demand' },
        restNonce: 'nonce-123',
      }),
    );
  });

  it('fetches retention status from the configured endpoint with the admin nonce', async () => {
    mockConfig.endpoints.retentionStatus = 'https://example.com/retentionStatus';
    fetchApiMock.mockResolvedValue({
      available: true,
      policy: {
        retention_mode: 'dispose_after_ack',
        last_export_at: '2026-03-12T12:00:00Z',
        last_purge_at: null,
        retention_updated_at: '2026-03-12T12:30:00Z',
      },
      recent_audit_events: [],
    });

    const result = await fetchRetentionStatus();

    expect(result).toEqual({
      available: true,
      policy: {
        retention_mode: 'dispose_after_ack',
        last_export_at: '2026-03-12T12:00:00Z',
        last_purge_at: null,
        retention_updated_at: '2026-03-12T12:30:00Z',
      },
      recent_audit_events: [],
    });
    expect(fetchApiMock).toHaveBeenCalledWith(
      expect.stringContaining('/retentionStatus'),
      expect.objectContaining({
        method: 'GET',
        restNonce: 'nonce-123',
      }),
    );
  });

  it('returns an unavailable retention status when the endpoint is not configured', async () => {
    const result = await fetchRetentionStatus();

    expect(result).toEqual({
      available: false,
      policy: null,
      recent_audit_events: [],
    });
    expect(fetchApiMock).not.toHaveBeenCalled();
  });

  it('posts purge requests to the retention purge endpoint', async () => {
    fetchApiMock.mockResolvedValue({ deleted_counts: { media_identities: 2 } });

    const result = await purgeTenantData({ scope: 'all', confirm: true });

    expect(result).toEqual({ deleted_counts: { media_identities: 2 } });
    expect(fetchApiMock).toHaveBeenCalledWith(
      expect.stringContaining('/retentionPurge'),
      expect.objectContaining({
        method: 'POST',
        body: { scope: 'all', confirm: true },
        restNonce: 'nonce-123',
      }),
    );
  });

  it('normalizes pending suggestion envelope payloads from the WP proxy', async () => {
    fetchApiMock.mockResolvedValue({
      suggestions: [
        {
          id: 's-1',
          identity_id: 'identity-1',
          cluster_id: 'cluster-1',
          rep_similarity: 0.87,
          member_similarity: null,
          status: 'pending',
        },
      ],
      total: 1,
      limit: 10,
      offset: 5,
      data_source: 'backend_proxy',
    });

    const result = await fetchPendingSuggestions(10, 5);

    expect(result.total).toBe(1);
    expect(result.limit).toBe(10);
    expect(result.offset).toBe(5);
    expect(result.suggestions[0]).toMatchObject({
      id: 's-1',
      identity_id: 'identity-1',
      suggested_cluster_id: 'cluster-1',
      representative_similarity: 0.87,
      avg_member_similarity: 0.87,
      confidence_score: 0.87,
    });
    expect(result.data_source).toBe(DATA_SOURCE.BACKEND_PROXY);
  });

  it('normalizes pending merge suggestion envelope payloads from the WP proxy', async () => {
    fetchApiMock.mockResolvedValue({
      suggestions: [
        {
          id: 'm-1',
          cluster_a_id: 'cluster-a',
          cluster_b_id: 'cluster-b',
          similarity: 0.93,
          status: 'pending',
        },
      ],
      total: 1,
      limit: 25,
      offset: 0,
      data_source: 'backend_proxy',
    });

    const result = await fetchPendingMergeSuggestions(25, 0);

    expect(result.total).toBe(1);
    expect(result.limit).toBe(25);
    expect(result.offset).toBe(0);
    expect(result.suggestions[0]).toMatchObject({
      id: 'm-1',
      cluster_a_id: 'cluster-a',
      cluster_b_id: 'cluster-b',
      similarity: 0.93,
      status: 'pending',
      cluster_a_label: null,
      cluster_b_label: null,
    });
    expect(result.data_source).toBe(DATA_SOURCE.BACKEND_PROXY);
  });

  it('builds cluster list query params through URLSearchParams', async () => {
    fetchApiMock.mockResolvedValue([]);

    await listRecognitionClusters({
      limit: 20,
      offset: 5,
      labeled_only: true,
      search: 'Alex Carter',
    });

    expect(fetchApiMock).toHaveBeenCalledTimes(1);
    const [endpoint, options] = fetchApiMock.mock.calls[0] ?? [];
    const url = new URL(endpoint);

    expect(url.searchParams.get('limit')).toBe('20');
    expect(url.searchParams.get('offset')).toBe('5');
    expect(url.searchParams.get('labeled_only')).toBe('true');
    expect(url.searchParams.get('search')).toBe('Alex Carter');
    expect(options).toMatchObject({ method: 'GET', restNonce: 'nonce-123' });
  });

  it('requests a single cluster detail from the canonical cluster endpoint', async () => {
    fetchApiMock.mockResolvedValue({
      id: 'cluster-9',
      label: 'Cluster 9',
      identity_count: 1,
      member_ids: ['identity-1'],
      representative_identity: { media_id: 1, bbox: { x: 0, y: 0, width: 1, height: 1 } },
      sample_identities: [],
    });

    await getRecognitionCluster('cluster-9');

    expect(fetchApiMock).toHaveBeenCalledWith(expect.stringContaining('/cluster-9'), {
      method: 'GET',
      restNonce: 'nonce-123',
    });
  });

  it('normalizes top-unlabeled representative thumbnail fields', async () => {
    fetchApiMock.mockResolvedValue({
      clusters: [
        {
          id: 'cluster-1',
          tenant_id: 'tenant-1',
          label: null,
          is_labeled: false,
          is_auto_label: false,
          identity_count: 2,
          user_confirmed: false,
          representatives: [
            {
              id: 'rep-1',
              media_id: 101,
              is_pinned: false,
              thumb_url: 'http://example.test/thumb-101.jpg',
              media_url: ' ',
              bbox: null,
            },
            {
              id: 'rep-2',
              media_id: 202,
              is_pinned: false,
              thumb_url: 'http://example.test/thumb-202.jpg',
              media_url: 'http://example.test/media-202.jpg',
              bbox: null,
            },
          ],
        },
      ],
      singleton_count: 4,
      data_source: 'local_projection',
      projection_status: 'available',
    });

    const result = await fetchTopUnlabeledClusters('tenant-1', 3);

    expect(result.singleton_count).toBe(4);
    expect(result.clusters[0]?.representatives[0]).toMatchObject({
      thumb_url: 'http://example.test/thumb-101.jpg',
      media_url: null,
    });
    expect(result.clusters[0]?.representatives[1]).toMatchObject({
      thumb_url: 'http://example.test/thumb-202.jpg',
      media_url: 'http://example.test/media-202.jpg',
    });

    const [endpoint] = fetchApiMock.mock.calls[0] ?? [];
    const url = new URL(endpoint);
    expect(url.searchParams.get('tenant_id')).toBe('tenant-1');
    expect(url.searchParams.get('limit')).toBe('3');
  });

  it('fetches sync status with nonce', async () => {
    fetchApiMock.mockResolvedValue({
      last_snapshot_version: 10,
      last_synced_at: '2026-02-14 00:00:00',
      is_stale: false,
    });

    await fetchSyncStatus();

    expect(fetchApiMock).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        method: 'GET',
        restNonce: 'nonce-123',
      }),
    );
  });

  it('keeps undismiss cluster operation on the DELETE contract', async () => {
    fetchMutationMock.mockResolvedValue(undefined);

    await undismissCluster('cluster-42');

    expect(fetchMutationMock).toHaveBeenCalledWith(expect.stringContaining('/cluster-42/dismiss'), {
      method: 'DELETE',
      restNonce: 'nonce-123',
      signal: undefined,
    });
  });

  it('triggers sync with POST method', async () => {
    fetchApiMock.mockResolvedValue({
      synced: true,
      reason: 'ok',
      last_snapshot_version: 1,
      last_synced_at: '2026-02-18 10:00:00',
      is_stale: false,
    });

    await triggerSync();

    expect(fetchApiMock).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        method: 'POST',
        restNonce: 'nonce-123',
      }),
    );
  });

  it('uses a stable sub-path slash for job mutations when the base endpoint has a trailing slash', async () => {
    const { getEndpoint } = await import('../config');
    vi.mocked(getEndpoint).mockImplementation((...keys: string[]) => `https://example.com/${keys[0] ?? 'default'}/`);
    fetchApiMock.mockResolvedValue({ status: 'acknowledged', snapshot_version: 3 });

    await acknowledgeProjection('job-3', 3);
    await cancelScanJob('job-4');

    expect(fetchApiMock).toHaveBeenNthCalledWith(
      1,
      'https://example.com/recognitionJobs/job-3/acknowledge-projection',
      expect.objectContaining({ method: 'POST' }),
    );
    expect(fetchApiMock).toHaveBeenNthCalledWith(
      2,
      'https://example.com/recognitionJobs/job-4/cancel',
      expect.objectContaining({ method: 'POST' }),
    );
  });
});
