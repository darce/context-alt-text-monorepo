<?php

declare(strict_types=1);

namespace AltContext\Api;

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

use function absint;
use function array_keys;
use function count;
use function is_array;
use function range;
use function sanitize_text_field;
use function sprintf;

class SuggestionsController extends AbstractRecognitionProxyController {
	private const DATA_SOURCE_BACKEND_PROXY = 'backend_proxy';
	private const DATA_SOURCE_UNAVAILABLE = 'unavailable';
	private const REQUEST_CLASS_POST_SCAN_READ = 'post_scan_read';

	public function register_routes(): void {
		register_rest_route(
			'acx/v1',
			'/recognition/identities/(?P<identity_id>[a-f0-9-]+)/suggestions',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_identity_suggestions' ),
				'permission_callback' => array( $this, 'can_manage_recognition' ),
			)
		);

		register_rest_route(
			'acx/v1',
			'/recognition/suggestions',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_pending_suggestions' ),
				'permission_callback' => array( $this, 'can_manage_recognition' ),
				'args'                => array(
					'limit'  => array(
						'type'        => 'integer',
						'default'     => 10,
						'description' => 'Maximum number of suggestions to return.',
					),
					'offset' => array(
						'type'        => 'integer',
						'default'     => 0,
						'description' => 'Number of suggestions to skip.',
					),
				),
			)
		);

		register_rest_route(
			'acx/v1',
			'/recognition/suggestions/merge',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_pending_merge_suggestions' ),
				'permission_callback' => array( $this, 'can_manage_recognition' ),
				'args'                => array(
					'limit'  => array(
						'type'        => 'integer',
						'default'     => 10,
						'description' => 'Maximum number of merge suggestions to return.',
					),
					'offset' => array(
						'type'        => 'integer',
						'default'     => 0,
						'description' => 'Number of merge suggestions to skip.',
					),
				),
			)
		);

		register_rest_route(
			'acx/v1',
			'/recognition/suggestions/(?P<suggestion_id>[a-f0-9-]+)/accept',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'accept_suggestion' ),
				'permission_callback' => array( $this, 'can_manage_recognition' ),
			)
		);

		register_rest_route(
			'acx/v1',
			'/recognition/suggestions/merge/(?P<suggestion_id>[a-f0-9-]+)/accept',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'accept_merge_suggestion' ),
				'permission_callback' => array( $this, 'can_manage_recognition' ),
			)
		);

		register_rest_route(
			'acx/v1',
			'/recognition/suggestions/(?P<suggestion_id>[a-f0-9-]+)/reject',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'reject_suggestion' ),
				'permission_callback' => array( $this, 'can_manage_recognition' ),
			)
		);

		register_rest_route(
			'acx/v1',
			'/recognition/suggestions/merge/(?P<suggestion_id>[a-f0-9-]+)/reject',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'reject_merge_suggestion' ),
				'permission_callback' => array( $this, 'can_manage_recognition' ),
			)
		);

		register_rest_route(
			'acx/v1',
			'/recognition/suggestions/name',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_name_suggestions' ),
				'permission_callback' => array( $this, 'can_manage_recognition' ),
				'args'                => array(
					'min_confidence' => array(
						'type'    => 'number',
						'default' => 0.0,
					),
					'limit'          => array(
						'type'    => 'integer',
						'default' => 25,
					),
					'offset'         => array(
						'type'    => 'integer',
						'default' => 0,
					),
				),
			)
		);

		register_rest_route(
			'acx/v1',
			'/recognition/suggestions/name/(?P<suggestion_id>[a-f0-9-]+)/accept',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'accept_name_suggestion' ),
				'permission_callback' => array( $this, 'can_manage_recognition' ),
			)
		);

		register_rest_route(
			'acx/v1',
			'/recognition/suggestions/name/(?P<suggestion_id>[a-f0-9-]+)/reject',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'reject_name_suggestion' ),
				'permission_callback' => array( $this, 'can_manage_recognition' ),
			)
		);

		register_rest_route(
			'acx/v1',
			'/recognition/suggestions/bulk-accept',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'bulk_accept_suggestions' ),
				'permission_callback' => array( $this, 'can_manage_recognition' ),
				'args'                => array(
					'suggestion_type' => array(
						'type'     => 'string',
						'required' => true,
					),
					'min_confidence'  => array(
						'type'    => 'number',
						'default' => 0.0,
					),
				),
			)
		);
	}

	public function get_identity_suggestions( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$identity_id = sanitize_text_field( (string) $request->get_param( 'identity_id' ) );

		if ( '' === $identity_id ) {
			return new WP_Error( 'missing_identity_id', 'Identity ID is required.', array( 'status' => 400 ) );
		}

		$query = array(
			'tenant_id' => $this->get_tenant_id(),
			'top_k'     => absint( $request->get_param( 'top_k' ) ?? 5 ),
			'threshold' => (float) ( $request->get_param( 'threshold' ) ?? 0.6 ),
		);

		$response = $this->proxy_request(
			'GET',
			sprintf( '/recognition/identities/%s/suggestions', $identity_id ),
			array(),
			$query
		);
		if ( $this->is_backend_overloaded( $response ) ) {
			return parent::backend_overloaded_response( $response );
		}
		if ( $this->is_proxy_unavailable( $response ) ) {
			return new WP_REST_Response(
				array(
					'matches' => array(),
				),
				200
			);
		}

		return $response;
	}

	public function get_pending_suggestions( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$query = array(
			'tenant_id' => $this->get_tenant_id(),
			'limit'     => absint( $request->get_param( 'limit' ) ?? 10 ),
			'offset'    => absint( $request->get_param( 'offset' ) ?? 0 ),
		);

		$response = $this->proxy_request(
			'GET',
			'/recognition/suggestions',
			array(),
			$query,
			self::REQUEST_CLASS_POST_SCAN_READ
		);
		if ( $this->is_backend_overloaded( $response ) ) {
			return parent::backend_overloaded_response( $response );
		}
		if ( $this->is_proxy_unavailable( $response ) ) {
			return $this->empty_pending_suggestions_response( (int) $query['limit'], (int) $query['offset'] );
		}

		return $this->normalize_pending_suggestions_response( $response, (int) $query['limit'], (int) $query['offset'] );
	}

	public function get_pending_merge_suggestions( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$query = array(
			'tenant_id' => $this->get_tenant_id(),
			'limit'     => absint( $request->get_param( 'limit' ) ?? 10 ),
			'offset'    => absint( $request->get_param( 'offset' ) ?? 0 ),
		);

		$response = $this->proxy_request(
			'GET',
			'/recognition/suggestions/merge',
			array(),
			$query,
			self::REQUEST_CLASS_POST_SCAN_READ
		);
		if ( $this->is_backend_overloaded( $response ) ) {
			return parent::backend_overloaded_response( $response );
		}
		if ( $this->is_proxy_unavailable( $response ) ) {
			return $this->empty_pending_suggestions_response( (int) $query['limit'], (int) $query['offset'] );
		}

		return $this->normalize_pending_suggestions_response( $response, (int) $query['limit'], (int) $query['offset'] );
	}

	public function accept_suggestion( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$suggestion_id = sanitize_text_field( (string) $request->get_param( 'suggestion_id' ) );

		if ( '' === $suggestion_id ) {
			return new WP_Error( 'missing_suggestion_id', 'Suggestion ID is required.', array( 'status' => 400 ) );
		}

		$payload = array(
			'tenant_id' => $this->get_tenant_id(),
		);

		return $this->proxy_request(
			'POST',
			sprintf( '/recognition/suggestions/%s/accept', $suggestion_id ),
			$payload
		);
	}

	public function accept_merge_suggestion( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$suggestion_id = sanitize_text_field( (string) $request->get_param( 'suggestion_id' ) );

		if ( '' === $suggestion_id ) {
			return new WP_Error( 'missing_suggestion_id', 'Suggestion ID is required.', array( 'status' => 400 ) );
		}

		$payload = array(
			'tenant_id' => $this->get_tenant_id(),
		);

		return $this->proxy_request(
			'POST',
			sprintf( '/recognition/suggestions/merge/%s/accept', $suggestion_id ),
			$payload
		);
	}

	public function reject_suggestion( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$suggestion_id = sanitize_text_field( (string) $request->get_param( 'suggestion_id' ) );

		if ( '' === $suggestion_id ) {
			return new WP_Error( 'missing_suggestion_id', 'Suggestion ID is required.', array( 'status' => 400 ) );
		}

		$payload = array(
			'tenant_id' => $this->get_tenant_id(),
		);

		return $this->proxy_request(
			'POST',
			sprintf( '/recognition/suggestions/%s/reject', $suggestion_id ),
			$payload
		);
	}

	public function reject_merge_suggestion( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$suggestion_id = sanitize_text_field( (string) $request->get_param( 'suggestion_id' ) );

		if ( '' === $suggestion_id ) {
			return new WP_Error( 'missing_suggestion_id', 'Suggestion ID is required.', array( 'status' => 400 ) );
		}

		$payload = array(
			'tenant_id' => $this->get_tenant_id(),
		);

		return $this->proxy_request(
			'POST',
			sprintf( '/recognition/suggestions/merge/%s/reject', $suggestion_id ),
			$payload
		);
	}

	public function list_name_suggestions( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$query = array(
			'tenant_id'      => $this->get_tenant_id(),
			'min_confidence' => (float) ( $request->get_param( 'min_confidence' ) ?? 0.0 ),
			'limit'          => absint( $request->get_param( 'limit' ) ?? 25 ),
			'offset'         => absint( $request->get_param( 'offset' ) ?? 0 ),
		);

		$response = $this->proxy_request(
			'GET',
			'/recognition/suggestions/name',
			array(),
			$query,
			self::REQUEST_CLASS_POST_SCAN_READ
		);
		if ( $this->is_backend_overloaded( $response ) ) {
			return parent::backend_overloaded_response( $response );
		}
		if ( $this->is_proxy_unavailable( $response ) ) {
			return $this->empty_pending_name_suggestions_response( (int) $query['limit'], (int) $query['offset'] );
		}

		return $this->normalize_pending_name_suggestions_response( $response, (int) $query['limit'], (int) $query['offset'] );
	}

	public function accept_name_suggestion( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$suggestion_id = sanitize_text_field( (string) $request->get_param( 'suggestion_id' ) );

		if ( '' === $suggestion_id ) {
			return new WP_Error( 'missing_suggestion_id', 'Suggestion ID is required.', array( 'status' => 400 ) );
		}

		$payload = array(
			'tenant_id' => $this->get_tenant_id(),
		);

		return $this->proxy_request(
			'POST',
			sprintf( '/recognition/suggestions/name/%s/accept', $suggestion_id ),
			$payload
		);
	}

	public function reject_name_suggestion( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$suggestion_id = sanitize_text_field( (string) $request->get_param( 'suggestion_id' ) );

		if ( '' === $suggestion_id ) {
			return new WP_Error( 'missing_suggestion_id', 'Suggestion ID is required.', array( 'status' => 400 ) );
		}

		$payload = array(
			'tenant_id' => $this->get_tenant_id(),
		);

		return $this->proxy_request(
			'POST',
			sprintf( '/recognition/suggestions/name/%s/reject', $suggestion_id ),
			$payload
		);
	}

	public function bulk_accept_suggestions( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$suggestion_type = sanitize_text_field( (string) ( $request->get_param( 'suggestion_type' ) ?? '' ) );
		if ( '' === $suggestion_type ) {
			return new WP_Error( 'missing_suggestion_type', 'Suggestion type is required.', array( 'status' => 400 ) );
		}

		$payload = array(
			'tenant_id'       => $this->get_tenant_id(),
			'suggestion_type' => $suggestion_type,
			'min_confidence'  => (float) ( $request->get_param( 'min_confidence' ) ?? 0.0 ),
		);

		$response = $this->proxy_request(
			'POST',
			'/recognition/suggestions/bulk-accept',
			$payload
		);
		if ( $this->is_backend_overloaded( $response ) ) {
			return parent::backend_overloaded_response( $response );
		}
		if ( $this->is_proxy_unavailable( $response ) ) {
			return new WP_REST_Response(
				array(
					'accepted_count' => 0,
					'skipped_count'  => 0,
				),
				200
			);
		}

		return $response;
	}
	private function empty_pending_suggestions_response( int $limit, int $offset ): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'suggestions' => array(),
				'total'       => 0,
				'limit'       => $limit,
				'offset'      => $offset,
				'data_source' => self::DATA_SOURCE_UNAVAILABLE,
			),
			200
		);
	}

	private function empty_pending_name_suggestions_response( int $limit, int $offset ): WP_REST_Response {
		return new WP_REST_Response(
			array(
				'suggestions' => array(),
				'total'       => 0,
				'limit'       => $limit,
				'offset'      => $offset,
				'data_source' => self::DATA_SOURCE_UNAVAILABLE,
			),
			200
		);
	}

	private function normalize_pending_suggestions_response( WP_REST_Response|WP_Error $response, int $limit, int $offset ): WP_REST_Response|WP_Error {
		if ( ! $response instanceof WP_REST_Response || 200 !== $response->get_status() ) {
			return $response;
		}

		$data = $response->get_data();
		if ( ! is_array( $data ) ) {
			return $response;
		}

		if ( ! $this->is_list_payload( $data ) ) {
			return new WP_Error(
				'invalid_suggestions_payload',
				'Suggestions payload must be a JSON array.',
				array( 'status' => 502 )
			);
		}

		return new WP_REST_Response(
			array(
				'suggestions' => $data,
				'total'       => count( $data ),
				'limit'       => $limit,
				'offset'      => $offset,
				'data_source' => self::DATA_SOURCE_BACKEND_PROXY,
			),
			200
		);
	}

	private function normalize_pending_name_suggestions_response( WP_REST_Response|WP_Error $response, int $limit, int $offset ): WP_REST_Response|WP_Error {
		if ( ! $response instanceof WP_REST_Response || 200 !== $response->get_status() ) {
			return $response;
		}

		$data = $response->get_data();
		if ( ! is_array( $data ) ) {
			return $response;
		}

		if ( ! $this->is_list_payload( $data ) ) {
			return new WP_Error(
				'invalid_name_suggestions_payload',
				'Name suggestions payload must be a JSON array.',
				array( 'status' => 502 )
			);
		}

		return new WP_REST_Response(
			array(
				'suggestions' => $data,
				'total'       => count( $data ),
				'limit'       => $limit,
				'offset'      => $offset,
				'data_source' => self::DATA_SOURCE_BACKEND_PROXY,
			),
			200
		);
	}

	private function is_list_payload( array $data ): bool {
		if ( array() === $data ) {
			return true;
		}

		return array_keys( $data ) === range( 0, count( $data ) - 1 );
	}
}
