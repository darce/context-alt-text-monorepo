import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

import { queryKeys } from '../api/queryKeys';
import { listRosterEntries, createPerson, updatePerson, deletePerson, type RosterEntry } from '../api/rosterApi';

const rosterEntriesKey = queryKeys.roster.entries();

interface RosterMutationContext {
  previousEntries: RosterEntry[] | undefined;
  optimisticId?: number;
}

export const useRosterEntries = () =>
  useQuery<RosterEntry[]>({
    queryKey: rosterEntriesKey,
    queryFn: () => listRosterEntries(),
    refetchInterval: 60_000,
  });

export const useCreatePerson = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ name, tags }: { name: string; tags?: string[] }) => createPerson(name, tags),
    onMutate: async ({ name, tags }) => {
      await queryClient.cancelQueries({ queryKey: rosterEntriesKey });
      const previousEntries = queryClient.getQueryData<RosterEntry[]>(rosterEntriesKey);
      const optimisticEntry: RosterEntry = {
        id: -Date.now(),
        name,
        tags: tags ?? [],
        cluster_count: 0,
        updated_at: new Date().toISOString(),
      };
      queryClient.setQueryData<RosterEntry[]>(rosterEntriesKey, (current) => [...(current ?? []), optimisticEntry]);
      return { previousEntries, optimisticId: optimisticEntry.id };
    },
    onError: (_error, _variables, context) => {
      if (context?.previousEntries) {
        queryClient.setQueryData(rosterEntriesKey, context.previousEntries);
      }
    },
    onSuccess: (createdEntry, _variables, context) => {
      queryClient.setQueryData<RosterEntry[]>(rosterEntriesKey, (current) => {
        const withoutOptimistic = (current ?? []).filter((entry) => entry.id !== context?.optimisticId);
        return [...withoutOptimistic, createdEntry];
      });
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: queryKeys.roster.all });
    },
  });
};

export const useUpdatePerson = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, name, tags }: { id: number; name?: string; tags?: string[] }) => updatePerson(id, name, tags),
    onMutate: async ({ id, name, tags }): Promise<RosterMutationContext> => {
      await queryClient.cancelQueries({ queryKey: rosterEntriesKey });
      const previousEntries = queryClient.getQueryData<RosterEntry[]>(rosterEntriesKey);
      queryClient.setQueryData<RosterEntry[]>(rosterEntriesKey, (current) =>
        (current ?? []).map((entry) =>
          entry.id === id
            ? {
                ...entry,
                name: name ?? entry.name,
                tags: tags ?? entry.tags,
              }
            : entry,
        ),
      );
      return { previousEntries };
    },
    onError: (_error, _variables, context) => {
      if (context?.previousEntries) {
        queryClient.setQueryData(rosterEntriesKey, context.previousEntries);
      }
    },
    onSuccess: (updatedEntry) => {
      queryClient.setQueryData<RosterEntry[]>(rosterEntriesKey, (current) =>
        (current ?? []).map((entry) => (entry.id === updatedEntry.id ? updatedEntry : entry)),
      );
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: queryKeys.roster.all });
    },
  });
};

export const useDeletePerson = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => deletePerson(id),
    onMutate: async (id): Promise<RosterMutationContext> => {
      await queryClient.cancelQueries({ queryKey: rosterEntriesKey });
      const previousEntries = queryClient.getQueryData<RosterEntry[]>(rosterEntriesKey);
      queryClient.setQueryData<RosterEntry[]>(rosterEntriesKey, (current) =>
        (current ?? []).filter((entry) => entry.id !== id),
      );
      return { previousEntries };
    },
    onError: (_error, _variables, context) => {
      if (context?.previousEntries) {
        queryClient.setQueryData(rosterEntriesKey, context.previousEntries);
      }
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: queryKeys.roster.all });
      void queryClient.invalidateQueries({ queryKey: queryKeys.clusters.all });
    },
  });
};
