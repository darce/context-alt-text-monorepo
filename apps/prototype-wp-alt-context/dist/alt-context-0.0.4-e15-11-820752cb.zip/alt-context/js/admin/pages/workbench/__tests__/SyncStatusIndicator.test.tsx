import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi, beforeEach } from 'vitest';

import type { UseMutationResult, UseQueryResult } from '@tanstack/react-query';
import type { RetentionStatusResponse, SyncStatusResponse, SyncTriggerResponse } from '../../../api/recognition';
import { createMockQuery } from '../../../test-utils/mockHooks';

const buildSyncStatus = (overrides: Partial<SyncStatusResponse> = {}): SyncStatusResponse => ({
  last_snapshot_version: 0,
  last_synced_at: null,
  is_stale: false,
  sync_health: 'healthy',
  last_sync_result: 'ok',
  ...overrides,
});

const buildSyncTriggerResponse = (overrides: Partial<SyncTriggerResponse> = {}): SyncTriggerResponse => ({
  synced: false,
  reason: 'sync_failed',
  last_snapshot_version: 0,
  last_synced_at: null,
  is_stale: true,
  sync_health: 'offline',
  last_sync_result: 'unreachable',
  ...overrides,
});

const mockReturn = {
  data: null as SyncStatusResponse | null | undefined,
  isLoading: false,
  isError: false,
};

const retentionQueryState = {
  data: {
    available: true,
    policy: {
      retention_mode: 'dispose_after_ack',
      last_export_at: null,
      last_purge_at: null,
      retention_updated_at: null,
    },
    recent_audit_events: [],
  } as RetentionStatusResponse | null | undefined,
};

const mutateSpy = vi.fn();

const mockTrigger = {
  isPending: false,
  isSuccess: false,
  isError: false,
  data: null as SyncTriggerResponse | null | undefined,
  mutate: mutateSpy,
} as unknown as UseMutationResult<SyncTriggerResponse, Error, void, unknown>;

vi.mock('@wordpress/i18n', () => ({
  __: (text: string) => text,
  sprintf: (text: string, ...values: (string | number)[]): string => {
    let result = text;
    for (const value of values) {
      result = result.replace(/%(?:[0-9]+\$)?[sd]/, String(value));
    }
    return result;
  },
}));

vi.mock('../../../hooks/useSyncStatus', () => ({
  useSyncStatus: () => mockReturn as unknown as UseQueryResult<SyncStatusResponse>,
}));

vi.mock('../../../hooks/useSyncTrigger', () => ({
  useSyncTrigger: () => mockTrigger,
}));

vi.mock('../../../hooks/useRetentionStatus', () => ({
  useRetentionStatus: () =>
    createMockQuery({
      data: retentionQueryState.data,
    }),
}));

import { SyncStatusIndicator } from '../SyncStatusIndicator';

describe('SyncStatusIndicator', () => {
  beforeEach(() => {
    mockReturn.data = null;
    mockReturn.isLoading = false;
    mockReturn.isError = false;
    retentionQueryState.data = {
      available: true,
      policy: {
        retention_mode: 'dispose_after_ack',
        last_export_at: null,
        last_purge_at: null,
        retention_updated_at: null,
      },
      recent_audit_events: [],
    };
    mutateSpy.mockClear();
    (mockTrigger as Record<string, unknown>).isPending = false;
    (mockTrigger as Record<string, unknown>).isSuccess = false;
    (mockTrigger as Record<string, unknown>).isError = false;
    (mockTrigger as Record<string, unknown>).data = null;
  });

  it('returns null when loading', () => {
    mockReturn.isLoading = true;

    const { container } = render(<SyncStatusIndicator />);
    expect(container.firstChild).toBeNull();
  });

  it('renders unavailable message when error occurs', () => {
    mockReturn.isError = true;

    render(<SyncStatusIndicator />);

    expect(screen.getByText('Sync status unavailable')).toBeInTheDocument();
  });

  it('renders unavailable message when data is null', () => {
    render(<SyncStatusIndicator />);

    expect(screen.getByText('Sync status unavailable')).toBeInTheDocument();
  });

  it('renders stale status badge when sync health is stale', () => {
    mockReturn.data = buildSyncStatus({
      last_snapshot_version: 2,
      last_synced_at: '2026-02-14 00:00:00',
      is_stale: true,
      sync_health: 'stale',
    });

    render(<SyncStatusIndicator />);

    expect(screen.getByText('Stale')).toBeInTheDocument();
    expect(screen.getByText(/Last sync/)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Sync now' })).toBeInTheDocument();
  });

  it('renders fresh badge when sync health is healthy', () => {
    mockReturn.data = buildSyncStatus({ last_snapshot_version: 5, last_synced_at: '2026-02-14 12:00:00' });

    render(<SyncStatusIndicator />);

    expect(screen.getByText('Fresh')).toBeInTheDocument();
    expect(screen.getByText(/Last sync/)).toBeInTheDocument();
  });

  it('shows a retention badge link when the mode is not retain_all', () => {
    mockReturn.data = buildSyncStatus({ last_snapshot_version: 5, last_synced_at: '2026-02-14 12:00:00' });

    render(<SyncStatusIndicator />);

    expect(screen.getByRole('link', { name: 'Retention: Dispose after ack' })).toHaveAttribute('href', '#/retention');
  });

  it('renders delta sync mode when provided', () => {
    mockReturn.data = buildSyncStatus({
      last_snapshot_version: 5,
      last_synced_at: '2026-02-14 12:00:00',
      sync_mode: 'delta',
    });

    render(<SyncStatusIndicator />);

    expect(screen.getByText('Delta sync')).toBeInTheDocument();
  });

  it('renders full sync mode when provided', () => {
    mockReturn.data = buildSyncStatus({
      last_snapshot_version: 5,
      last_synced_at: '2026-02-14 12:00:00',
      sync_mode: 'full',
    });

    render(<SyncStatusIndicator />);

    expect(screen.getByText('Full sync')).toBeInTheDocument();
  });

  it('shows the purge-on-demand retention badge label when configured', () => {
    mockReturn.data = buildSyncStatus({ last_snapshot_version: 5, last_synced_at: '2026-02-14 12:00:00' });
    retentionQueryState.data = {
      available: true,
      policy: {
        retention_mode: 'purge_on_demand',
        last_export_at: null,
        last_purge_at: null,
        retention_updated_at: null,
      },
      recent_audit_events: [],
    };

    render(<SyncStatusIndicator />);

    expect(screen.getByRole('link', { name: 'Retention: Purge on demand' })).toHaveAttribute('href', '#/retention');
  });

  it('does not show a retention badge when the policy is retain_all', () => {
    mockReturn.data = buildSyncStatus({ last_snapshot_version: 5, last_synced_at: '2026-02-14 12:00:00' });
    retentionQueryState.data = {
      available: true,
      policy: {
        retention_mode: 'retain_all',
        last_export_at: null,
        last_purge_at: null,
        retention_updated_at: null,
      },
      recent_audit_events: [],
    };

    render(<SyncStatusIndicator />);

    expect(screen.queryByRole('link', { name: /Retention:/ })).not.toBeInTheDocument();
  });

  it('does not show a retention badge when retention status is unavailable', () => {
    mockReturn.data = buildSyncStatus({ last_snapshot_version: 5, last_synced_at: '2026-02-14 12:00:00' });
    retentionQueryState.data = {
      available: false,
      policy: null,
      recent_audit_events: [],
    };

    render(<SyncStatusIndicator />);

    expect(screen.queryByRole('link', { name: /Retention:/ })).not.toBeInTheDocument();
  });

  it('renders queued state when pending replay exists without failures or conflicts', () => {
    mockReturn.data = buildSyncStatus({
      sync_health: 'queued',
      pending_curation_operations: 4,
      is_stale: false,
    });

    render(<SyncStatusIndicator />);

    expect(screen.getByText('Local curation changes are queued for replay.')).toBeInTheDocument();
    expect(screen.getByText('Queued')).toBeInTheDocument();
  });

  it('renders failures state with dead-letter affordance', () => {
    mockReturn.data = buildSyncStatus({
      sync_health: 'failures',
      failed_curation_operations: 2,
    });

    render(<SyncStatusIndicator />);

    expect(screen.getByText('Curation replay needs attention.')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Failures' })).toHaveAttribute(
      'href',
      '#/workbench?tab=scan&panel=dead-letter',
    );
    expect(screen.getByRole('link', { name: 'Failed replay: 2' })).toHaveAttribute(
      'href',
      '#/workbench?tab=scan&panel=dead-letter',
    );
  });

  it('renders offline idle state when no transient sync operation is active', () => {
    mockReturn.data = buildSyncStatus({
      sync_health: 'offline',
      is_stale: false,
      last_sync_result: 'unreachable',
    });

    const { container } = render(<SyncStatusIndicator />);

    expect(screen.getByText('Waiting for service…')).toBeInTheDocument();
    expect(screen.getByText('Offline')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Retry' })).toBeInTheDocument();
    expect(container.firstChild).toHaveClass('acx-sync-status--warning');
  });

  it('renders syncing state when trigger is pending', () => {
    mockReturn.data = buildSyncStatus({ is_stale: true, sync_health: 'stale' });
    (mockTrigger as Record<string, unknown>).isPending = true;

    render(<SyncStatusIndicator />);

    expect(screen.getByText('Syncing…')).toBeInTheDocument();
    expect(screen.getByText('In Progress')).toBeInTheDocument();
  });

  it('renders success state after sync completes', () => {
    mockReturn.data = buildSyncStatus({ last_snapshot_version: 1, last_synced_at: '2026-02-18 10:00:00' });
    (mockTrigger as Record<string, unknown>).isSuccess = true;
    (mockTrigger as Record<string, unknown>).data = buildSyncTriggerResponse({
      synced: true,
      reason: 'ok',
      last_snapshot_version: 1,
      last_synced_at: '2026-02-18 10:00:00',
      is_stale: false,
      sync_health: 'healthy',
      last_sync_result: 'ok',
    });

    render(<SyncStatusIndicator />);

    expect(screen.getByText(/Sync completed/)).toBeInTheDocument();
    expect(screen.getByText('Fresh')).toBeInTheDocument();
  });

  it('renders waiting-for-service state when sync was attempted but failed', () => {
    mockReturn.data = buildSyncStatus({ is_stale: true, sync_health: 'offline', last_sync_result: 'unreachable' });
    (mockTrigger as Record<string, unknown>).isSuccess = true;
    (mockTrigger as Record<string, unknown>).data = buildSyncTriggerResponse();

    render(<SyncStatusIndicator />);

    expect(screen.getByText('Waiting for service…')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Retry' })).toBeInTheDocument();
  });

  it('renders waiting-for-service state on trigger error', () => {
    mockReturn.data = buildSyncStatus({ is_stale: true, sync_health: 'offline', last_sync_result: 'unreachable' });
    (mockTrigger as Record<string, unknown>).isError = true;

    render(<SyncStatusIndicator />);

    expect(screen.getByText('Waiting for service…')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Retry' })).toBeInTheDocument();
  });

  it('calls mutate when retry is clicked', () => {
    mockReturn.data = buildSyncStatus({ is_stale: true, sync_health: 'offline', last_sync_result: 'unreachable' });
    (mockTrigger as Record<string, unknown>).isError = true;

    render(<SyncStatusIndicator />);

    fireEvent.click(screen.getByRole('button', { name: 'Retry' }));
    expect(mutateSpy).toHaveBeenCalledTimes(1);
  });

  it('calls mutate when sync now is clicked in stale idle state', () => {
    mockReturn.data = buildSyncStatus({
      last_snapshot_version: 2,
      last_synced_at: '2026-02-14 00:00:00',
      is_stale: true,
      sync_health: 'stale',
    });

    render(<SyncStatusIndicator />);

    fireEvent.click(screen.getByRole('button', { name: 'Sync now' }));
    expect(mutateSpy).toHaveBeenCalledTimes(1);
  });

  it('does not stay in waiting-for-service when stale flag clears', () => {
    mockReturn.data = buildSyncStatus({ last_snapshot_version: 2, last_synced_at: '2026-02-19 13:00:00' });
    (mockTrigger as Record<string, unknown>).isSuccess = true;
    (mockTrigger as Record<string, unknown>).data = buildSyncTriggerResponse({
      synced: false,
      reason: 'sync_failed',
      last_snapshot_version: 2,
      last_synced_at: '2026-02-19 13:00:00',
      is_stale: false,
      sync_health: 'healthy',
      last_sync_result: 'ok',
    });

    render(<SyncStatusIndicator />);

    expect(screen.queryByText('Waiting for service…')).not.toBeInTheDocument();
    expect(screen.getByText(/Last sync/)).toBeInTheDocument();
  });

  it('renders connected-no-clusters state on no_remote_data reason', () => {
    mockReturn.data = buildSyncStatus({ is_stale: true, sync_health: 'stale' });
    (mockTrigger as Record<string, unknown>).isSuccess = true;
    (mockTrigger as Record<string, unknown>).data = buildSyncTriggerResponse({
      synced: true,
      reason: 'no_remote_data',
      last_snapshot_version: 0,
      last_synced_at: null,
      is_stale: true,
      sync_health: 'stale',
      last_sync_result: 'ok',
    });

    render(<SyncStatusIndicator />);

    expect(screen.getByText(/Service connected/)).toBeInTheDocument();
    expect(screen.getByText(/no clusters yet/)).toBeInTheDocument();
    expect(screen.queryByText('Waiting for service…')).not.toBeInTheDocument();
  });

  it('renders curation replay counters and timestamps when available', () => {
    mockReturn.data = buildSyncStatus({
      last_snapshot_version: 8,
      last_synced_at: '2026-03-07 02:00:00',
      pending_curation_operations: 3,
      failed_curation_operations: 2,
      conflict_count: 1,
      last_curation_acknowledged_at: '2026-03-07T02:05:00Z',
      last_curation_conflict_at: '2026-03-07T02:15:00Z',
      last_curation_failed_at: '2026-03-07T02:25:00Z',
      sync_health: 'conflicts',
    });

    render(<SyncStatusIndicator activeSection="confirm" />);

    expect(screen.getByText('Pending curation: 3')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Conflicts' })).toHaveAttribute(
      'href',
      '#/workbench?tab=confirm&panel=conflicts',
    );
    expect(screen.getByRole('link', { name: 'Conflicts: 1' })).toHaveAttribute(
      'href',
      '#/workbench?tab=confirm&panel=conflicts',
    );
    expect(screen.getByRole('link', { name: 'Failed replay: 2' })).toHaveAttribute(
      'href',
      '#/workbench?tab=confirm&panel=dead-letter',
    );
    expect(screen.getByText(/Last curation acknowledgement:/)).toBeInTheDocument();
    expect(screen.getByText(/Last curation conflict:/)).toBeInTheDocument();
    expect(screen.getByText(/Last curation failure:/)).toBeInTheDocument();
  });

  it('renders topology backlog details when present', () => {
    mockReturn.data = buildSyncStatus({
      sync_health: 'queued',
      topology_commands: {
        pending: 2,
        applied: 5,
        failed: 1,
        conflict: 3,
        last_reconciled_at: null,
      },
    });

    render(<SyncStatusIndicator />);

    expect(screen.getByText('Topology backlog: pending 2, applied 5, failed 1, conflicts 3')).toBeInTheDocument();
  });

  it('renders projecting sync progress ahead of the generic stale indicator', () => {
    mockReturn.data = buildSyncStatus({
      last_snapshot_version: 4,
      last_synced_at: '2026-03-08 10:00:00',
      is_stale: true,
      sync_health: 'stale',
    });

    render(<SyncStatusIndicator pipelinePhase="projecting" projectionState="syncing" />);

    expect(screen.getByText('Syncing results…')).toBeInTheDocument();
    expect(screen.getByText('In Progress')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Sync now' })).not.toBeInTheDocument();
  });

  it('renders ready-for-review projection state before the final acknowledgement', () => {
    mockReturn.data = buildSyncStatus({
      last_snapshot_version: 4,
      last_synced_at: '2026-03-08 10:00:00',
      is_stale: true,
      sync_health: 'stale',
    });

    render(<SyncStatusIndicator pipelinePhase="projecting" projectionState="ready" />);

    expect(screen.getByText('Projected results ready for review.')).toBeInTheDocument();
    expect(screen.getByText('Ready')).toBeInTheDocument();
  });

  it('renders projection retry state with the provided error message', () => {
    const retryProjection = vi.fn();
    mockReturn.data = buildSyncStatus({
      last_snapshot_version: 4,
      last_synced_at: '2026-03-08 10:00:00',
      is_stale: true,
      sync_health: 'stale',
    });

    render(
      <SyncStatusIndicator
        pipelinePhase="projecting"
        projectionState="error"
        projectionError="Waiting for service…"
        onRetryProjection={retryProjection}
      />,
    );

    expect(screen.getByText('Waiting for service…')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Retry sync' }));
    expect(retryProjection).toHaveBeenCalledTimes(1);
  });

  it('keeps projection retry state visible after the pipeline leaves projecting', () => {
    const retryProjection = vi.fn();
    mockReturn.data = buildSyncStatus({
      last_snapshot_version: 4,
      last_synced_at: '2026-03-08 10:00:00',
      is_stale: true,
      sync_health: 'stale',
    });

    render(
      <SyncStatusIndicator
        pipelinePhase="idle"
        projectionState="error"
        projectionError="Waiting for service…"
        onRetryProjection={retryProjection}
      />,
    );

    expect(screen.getByText('Waiting for service…')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Retry sync' }));
    expect(retryProjection).toHaveBeenCalledTimes(1);
  });
});
